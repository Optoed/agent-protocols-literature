import sys,json,hashlib,asyncio,collections,math,random,contextlib,io
from pathlib import Path
root=Path.cwd();dev=root/'swarm-dev';runs=root/'workflow-runs';run=runs/'main-v5-confirmed-recovery2';out=root/'protocol-selection-review/qa/audit-20261105';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(dev))
from benchmarks.workflow_search.confirmed import experiment
from benchmarks.workflow_search.prepare_confirmed import build_plan
from benchmarks.workflow_search.answers_v2 import grade
from benchmarks.workflow_search.answers import grade as strict_grade
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(runs/'main-v5-confirmed-plan.json'); protocol=read(run/'protocol.json'); stored=read(run/'result.json'); checks={};failures=[]
def check(k,ok,detail=None):
 checks[k]={'pass':bool(ok),'detail':detail}
 if not ok:failures.append(k)
check('plan_hash',sha(runs/'main-v5-confirmed-plan.json')==protocol['plan_sha256'])
check('frozen_source_hashes',all(sha(dev/k)==v for k,v in protocol['source_hashes'].items()),len(protocol['source_hashes']))
check('dataset_snapshot_hashes',all(sha(runs/k)==v for k,v in plan['source_hashes'].items()),len(plan['source_hashes']))
check('previous_plan_hashes',all(sha(runs/k)==v for k,v in plan['exclusion_source_hashes'].items()))
rebuilt=build_plan(runs);rebuilt['registered_utc']=plan['registered_utc'];check('deterministic_task_selection',rebuilt==plan)
parts={k:{t['question'].strip() for t in plan[k]} for k in ['search','confirmation','test']}
check('disjoint_questions',not(parts['search']&parts['confirmation'] or parts['search']&parts['test'] or parts['confirmation']&parts['test']),{k:len(v) for k,v in parts.items()})
alltasks={t['id']:t for p in ['search','confirmation','test'] for t in plan[p]}
check('unique_tasks',len(alltasks)==80)
records={};actual={};statuses=collections.Counter();responseids=[];bad=[]
for kind in ['calls','interrupted_attempts/calls']:
 for p in (run/kind).glob('*.json'):
  d=read(p);statuses[kind+':'+d['status']]+=1
  c=actual.setdefault(d['category'],{'calls':0,'known_usd':0.,'unknown_cost_calls':0,'prompt_tokens':0,'completion_tokens':0,'unknown_usage_calls':0});c['calls']+=1
  cost=d.get('cost');u=d.get('response',{}).get('usage',{})
  if cost is None:c['unknown_cost_calls']+=1
  else:c['known_usd']+=cost
  if 'prompt_tokens' in u and 'completion_tokens' in u:
   c['prompt_tokens']+=u['prompt_tokens'];c['completion_tokens']+=u['completion_tokens']
  else:c['unknown_usage_calls']+=1
  if kind=='calls':
   records[d['identity']]=d;responseids.append(d.get('response',{}).get('id'))
   if p.stem!=hashlib.sha256(d['identity'].encode()).hexdigest():bad.append(p.name)
   if cost!=u.get('cost'):bad.append(p.name+':cost')
check('record_identity_hash_and_cost',not bad,bad)
check('unique_response_ids',len(responseids)==len(set(responseids)) and all(x and x.startswith('gen-') for x in responseids),len(responseids))
check('all_current_completed',all(d['status']=='completed' for d in records.values()))
check('request_parameters',all(d['request']['model']==plan['model'] and d['request']['temperature']==.2 and d['request']['max_tokens']==8192 for d in records.values()))
providers = dict(collections.Counter(d['response'].get('provider') for d in records.values()))
check('response_model_metadata',all(d['response'].get('model')==plan['model'] for d in records.values()),{'providers':providers,'note':'Provider was not pinned. Initial audit assumption that every response was served by OpenAI was false; Azure served 22 responses.'})
check('cost_recalculation',all(all(math.isclose(c[k],read(run/'costs.json')[cat][k],rel_tol=1e-10,abs_tol=1e-12) for k in c) for cat,c in actual.items()),actual)
check('plan_precedes_all_calls',plan['registered_utc']<min(d['started_utc'] for d in records.values()))
chain=[]
for name in ['main-v5-confirmed-recovery1','main-v5-confirmed-recovery2']:
 dest=runs/name;meta=read(dest/'recovery.json');good=0;archived=0;missing=[]
 archive_hash={sha(p) for p in (dest/'interrupted_attempts/calls').glob('*.json')}
 for filename,digest in meta['inherited_calls'].items():
  target=dest/'calls'/filename
  if target.exists() and sha(target)==digest:good+=1
  elif digest in archive_hash:archived+=1
  else:missing.append(filename)
 chain.append({'run':name,'matched_current':good,'matched_historical':archived,'missing':missing})
check('inheritance_manifests',all(not c['missing'] for c in chain),chain)
class ReadOnlyReplay:
 def __init__(self):self.used=collections.Counter()
 async def request(self,identity,body,category):
  if identity not in records:raise RuntimeError('missing record '+identity)
  d=records[identity]
  if d['request']!=body or d['category']!=category:raise RuntimeError('request mismatch '+identity)
  self.used[identity]+=1;return d['response']
 def costs(self):return actual
j=ReadOnlyReplay()
with contextlib.redirect_stdout(io.StringIO()): replay=asyncio.run(experiment(plan,out/'offline-replay',j))
check('offline_replay_no_errors',not replay['errors'],replay['errors'])
check('offline_replay_all_records_once',len(j.used)==len(records) and set(j.used.values())=={1},{'used':len(j.used),'recorded':len(records)})
check('offline_replay_replicates_equal',replay['replicates']==stored['replicates'])
original_evals=list((run/'evaluations').glob('*.json'));mismatches=[]
for p in original_evals:
 rp=out/'offline-replay/evaluations'/p.name
 if not rp.exists() or read(p)!=read(rp):mismatches.append(p.name)
check('all_evaluations_match_replay',not mismatches,{'count':len(original_evals),'mismatches':mismatches})
reps=[];vectors={mode:collections.defaultdict(list) for mode in ['independent','shared','shared_confirm']};graded_errors=[]
for rep in stored['replicates']:
 rs={'replicate':rep['replicate'],'winners':rep['winners'],'test':rep['test']};reps.append(rs)
 for fp in set(rep['winners'].values()):
  rows=read(run/f"test-{rep['replicate']}-{fp}.json")
  for row in rows:
   if grade(row['answer'],alltasks[row['id']]['answer'])[0]!=row['quality'] or strict_grade(row['answer'],alltasks[row['id']]['answer'])[0]!=row['strict_quality']:graded_errors.append(row['id'])
 for mode,fp in rep['winners'].items():
  for row in read(run/f"test-{rep['replicate']}-{fp}.json"):vectors[mode][row['id']].append(row['quality'])
check('test_rescoring',not graded_errors,graded_errors)
metrics={m:sum(sum(v) for v in d.values())/144 for m,d in vectors.items()}
deltas=[sum(vectors['shared_confirm'][tid])/3-sum(vectors['independent'][tid])/3 for tid in sorted(vectors['independent'])]
rng=random.Random(20261105);boot=sorted(sum(rng.choices(deltas,k=48))/48 for _ in range(20000))
comparison={'mean_delta':sum(deltas)/48,'task_cluster_bootstrap95_conditional_exploratory':[boot[500],boot[19499]],'positive_task_clusters':sum(d>0 for d in deltas),'negative_task_clusters':sum(d<0 for d in deltas),'tied_task_clusters':sum(d==0 for d in deltas),'caveat':'Resamples 48 test tasks with all three repeat outcomes together; conditional on observed selected workflows; does not capture new search runs/model/domain variation.'}
summary={'audit_date':'2026-11-05','status':'pass' if not failures else 'fail','checks':checks,'failures':failures,'statuses':dict(statuses),'costs':actual,'known_total':sum(c['known_usd'] for c in actual.values()),'unknown_attempts':sum(c['unknown_cost_calls'] for c in actual.values()),'accuracies':metrics,'known_search_saving':1-(actual['shared_search']['known_usd']+actual['confirmation_search']['known_usd'])/actual['independent_search']['known_usd'],'replicates':reps,'exploratory_uncertainty':comparison,'evidence_scope':'Local request/response provenance and exact offline replay, not a provider-side billing attestation. No network or model calls made.'}
(out/'v5-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['checks','replicates']},ensure_ascii=True,indent=2))
