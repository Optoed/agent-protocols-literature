from pathlib import Path
import json,re,urllib.request,concurrent.futures,hashlib
out=Path('protocol-selection-review/qa/audit-20261105')
plan=json.loads(Path('workflow-runs/main-v5-confirmed-plan.json').read_text())
tasks=[t for part in ['search','confirmation','test'] for t in plan[part]]
groups={}
for t in tasks:
 split='test' if '-test-' in t['id'] else 'train';key=(t['domain'],split,t['row_index']//100*100);groups.setdefault(key,[]).append(t)
def get_group(item):
 (domain,split,offset),ts=item;url=f'https://datasets-server.huggingface.co/rows?dataset=EleutherAI%2Fhendrycks_math&config={domain}&split={split}&offset={offset}&length=100'
 try:
  data=urllib.request.urlopen(url,timeout=25).read();p=out/f'hf-{domain}-{split}-{offset}.json';p.write_bytes(data);rows={r['row_idx']:r['row'] for r in json.loads(data)['rows']}
  checks=[{'id':t['id'],'question_equal':rows[t['row_index']]['problem']==t['question'],'level_equal':rows[t['row_index']]['level']==t['level'],'reference_occurs_in_solution':t['answer'] in rows[t['row_index']]['solution']} for t in ts]
  return {'url':url,'checks':checks,'sha256':hashlib.sha256(data).hexdigest()}
 except Exception as e:return {'url':url,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:res=list(ex.map(get_group,groups.items()))
(out/'dataset-live-checks.json').write_text(json.dumps(res,indent=2),encoding='utf-8')
print('dataset pages',len(res),'errors',sum('error' in r for r in res),'tasks',sum(len(r.get('checks',[])) for r in res));print([c for r in res for c in r.get('checks',[]) if not all(v for k,v in c.items() if k!='id')])
repos=['Ericccc02/AgentSwift','pandawei-ele/A2FLOW','BoYuanVisionary/BayesFlow'];cr=[]
for repo in repos:
 u='https://api.github.com/repos/'+repo+'/contents'
 try:
  d=json.loads(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'research-audit'}),timeout=20).read());cr.append({'repo':repo,'url':u,'entries':[{'name':x['name'],'type':x['type']} for x in d]})
 except Exception as e:cr.append({'repo':repo,'url':u,'error':str(e)})
(out/'code-live-checks.json').write_text(json.dumps(cr,indent=2),encoding='utf-8');print('code',cr)
