from pathlib import Path
import json,collections,re,datetime
from fractions import Fraction
from decimal import Decimal
root=Path.cwd();run=root/'workflow-runs/main-v5-confirmed-recovery2';out=root/'protocol-selection-review/qa/audit-20261105';plan=json.loads((root/'workflow-runs/main-v5-confirmed-plan.json').read_text());tasks={t['id']:t for k in ['search','confirmation','test'] for t in plan[k]}
def parse_value(s):
 s=s.strip().replace('−','-')
 if s.startswith('\\$'):s=s[2:].strip()
 if re.match(r'^[A-Za-z]\s*=',s):s=s.split('=',1)[1].strip()
 s=s.replace(' ','')
 if ',' in s:
  if not re.fullmatch(r'[+-]?\d{1,3}(,\d{3})+(\.\d+)?',s):return None
  s=s.replace(',','')
 m=re.fullmatch(r'([+-]?)\\(?:dfrac|tfrac|frac)\{([+-]?\d+)\}\{([+-]?\d+)\}',s)
 try:
  if m:return (-1 if m[1]=='-' else 1)*Fraction(int(m[2]),int(m[3]))
  if re.fullmatch(r'[+-]?\d+/[+-]?\d+',s):
   a,b=s.split('/');return Fraction(int(a),int(b))
  if re.fullmatch(r'[+-]?\d+(\.\d+)?',s):return Fraction(Decimal(s))
 except (ZeroDivisionError,ValueError):return None
 return None
def box(s):
 # Independent brace-stack implementation, last boxed expression.
 pos=s.rfind('\\boxed{')
 if pos<0:return None
 stack=[];start=pos+7
 for i,ch in enumerate(s[start:]):
  if ch=='{':stack.append(ch)
  elif ch=='}':
   if not stack:return s[start:start+i]
   stack.pop()
 return None
bad=[];broader=[];shapes=collections.Counter();n=0
for p in (run/'evaluations').glob('*.json'):
 d=json.loads(p.read_text());b=box(d['answer']);pred=parse_value(b) if b is not None else None;gold=parse_value(tasks[d['id']]['answer']);q=float(pred is not None and pred==gold);n+=1
 if q!=d['quality']:
  (bad if d['quality'] else broader).append({'file':p.name,'boxed':b,'gold':str(gold),'stored':d['quality'],'independent':q})
 shapes['correct' if d['quality'] else 'incorrect']+=1
records=[json.loads(p.read_text()) for p in (run/'calls').glob('*.json')];timing=[]
for r in range(3):
 rr=[d for d in records if f'/rep-{r}/' in d['identity']];search=[d for d in rr if d['category']!='test_execution'];test=[d for d in rr if d['category']=='test_execution']
 end=max(datetime.datetime.fromisoformat(d['started_utc'])+datetime.timedelta(seconds=d['elapsed_seconds']) for d in search);start=min(datetime.datetime.fromisoformat(d['started_utc']) for d in test);timing.append({'replicate':r,'last_search_end':end.isoformat(),'first_test_start':start.isoformat(),'search_before_test':end<=start})
reps=json.loads((run/'result.json').read_text())['replicates'];strict={m:0 for m in ['independent','shared','shared_confirm']}
for r in reps:
 for m,fp in r['winners'].items():strict[m]+=sum(d['strict_quality'] for d in json.loads((run/f"test-{r['replicate']}-{fp}.json").read_text()))
res={'independent_arithmetic_positive_false_matches':bad,'broader_parser_extra_matches':broader,'evaluation_count':n,'quality_counts':dict(shapes),'search_test_order':timing,'strict_correct_out_of_144':strict,'note':'Independent bounded rational parser; broader supported syntax is diagnostic only. Official scorer/results unchanged.'}
(out/'v5-independent-checks.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(res,ensure_ascii=False,indent=2)[:7500])
