import asyncio
from collections.abc import Awaitable, Callable

from fedotmas.engine import (
    Fact,
    Goal,
    ReactiveExecutor,
    Result,
    Store,
    System,
    View,
    as_node,
)


async def classify(input: object, view: View) -> Result:
    return Result(writes=[Fact(tag="route", value="math")])


def handler(label: str) -> Callable[[object, View], Awaitable[Result]]:
    async def run(input: object, view: View) -> Result:
        return Result(writes=[Fact(tag="answer", value=f"{label} handled")])

    return run


def routed(label: str) -> Callable[[View], bool]:
    return lambda v: v.value("route") == label


async def main() -> None:
    system = System(
        nodes=[
            as_node(classify, name="classifier", reads="q"),
            as_node(
                handler("code"), name="coder", reads="route", trigger=routed("code")
            ),
            as_node(
                handler("prose"), name="writer", reads="route", trigger=routed("prose")
            ),
            as_node(
                handler("math"), name="solver", reads="route", trigger=routed("math")
            ),
        ]
    )
    store = Store()
    stream = ReactiveExecutor().stream(
        system,
        store,
        seed=[Fact(tag="q", value="2 + 2")],
        terminate=[Goal("answer")],
    )
    async for r in stream:
        print(f"step {r.step}: {r.fired} -> {[f.tag for f in r.writes]}")
    print("answer:", store.snapshot().value("answer"))


if __name__ == "__main__":
    asyncio.run(main())
