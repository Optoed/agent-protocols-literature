import asyncio
from collections.abc import Awaitable, Callable

from fedotmas.engine import (
    AuctionSelect,
    Fact,
    Goal,
    ReactiveExecutor,
    Result,
    Store,
    System,
    View,
    as_node,
)

BIDS = {"w1": 0.3, "w2": 0.9, "w3": 0.5}


def worker(name: str) -> Callable[[object, View], Awaitable[Result]]:
    async def run(input: object, view: View) -> Result:
        return Result(
            writes=[
                Fact(tag="award", value=name),
                Fact(tag="result", value=f"{name} executed the task"),
            ]
        )

    return run


def open_task(v: View) -> bool:
    return v.exists("task") and not v.exists("award")


async def main() -> None:
    # the auction is the system's own discipline, so it holds wherever the system runs
    system = System(
        nodes=[
            as_node(worker(n), name=n, reads="task", trigger=open_task) for n in BIDS
        ],
        policy=AuctionSelect(key=lambda a, v: BIDS[a.name]),
    )
    store = Store()
    stream = ReactiveExecutor().stream(
        system,
        store,
        seed=[Fact(tag="task", value="haul cargo")],
        terminate=[Goal("result")],
    )
    async for r in stream:
        print(f"step {r.step}: {r.fired} -> {[f.tag for f in r.writes]}")
    snap = store.snapshot()
    print("award:", snap.value("award"), "| result:", snap.value("result"))


if __name__ == "__main__":
    asyncio.run(main())
