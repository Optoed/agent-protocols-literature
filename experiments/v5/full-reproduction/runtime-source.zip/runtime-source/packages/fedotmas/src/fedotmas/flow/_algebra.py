from __future__ import annotations

from collections.abc import AsyncIterator, Callable, Mapping, Sequence
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from fedotmas._addressing import Branch, Loop
from fedotmas._condition import Predicate, _pick, state_predicate
from fedotmas._inject import bind_pred
from fedotmas.engine.contract import Kind, Node, View
from fedotmas.engine.plugin import Plugin, PluginDispatcher
from fedotmas.engine.system import Compilable, System
from fedotmas.engine.terminate import Terminate
from fedotmas.flow._nodes import (
    Ctx,
    _alias_node,
    _collect_node,
    _into_node,
    _loop_finish_node,
    _loop_iterate_node,
    _merge_node,
    _nest_node,
    _route_node,
)

if TYPE_CHECKING:
    from fedotmas.engine.outcome import Outcome
    from fedotmas.engine.policy import Policy
    from fedotmas.engine.report import StepReport

A = TypeVar("A")
B = TypeVar("B")
C = TypeVar("C")


class Flow(Generic[A, B]):
    """A typed dataflow fragment from input A to output B. Make atoms with action (a code
    body), or an extension node-kind such as fedotmas-llm's agent, then compose: + is
    sequence, gather runs branches in parallel, branch routes by label, .loop iterates, nest
    wraps a whole sub-system as one node. `.system(entry, out)`
    compiles the fragment to an engine System; `.run(value)` compiles and executes it in one
    call. The type parameters check each stitch: a + b only type-checks when b accepts what a
    produces.
    """

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        raise NotImplementedError

    def system(
        self,
        *,
        entry: str = "in",
        out: str = "out",
        bind: Mapping[str, Any] | None = None,
        plugins: Sequence[Plugin] | PluginDispatcher = (),
        policy: Policy | None = None,
        halt_on_error: bool = True,
    ) -> System:
        """Compile to a runnable System — the Compilable face. A flow is anonymous dataflow,
        so `entry`/`out` are assigned, not referenced (the defaults are .run's own choice).
        `bind` is the run-scoped binding map threaded to every node's builder (e.g. a default
        backend under "llm"); a node that needs a binding nobody supplied fails here, not
        mid-run. `plugins` are baked into nested boundaries at compile: nest and loop nodes
        capture the observer face for their inner runs, which is why plugins given only at run
        time cannot reach inside an already-compiled system. `policy` and `halt_on_error`
        become the compiled system's own discipline (see System)."""
        ctx = Ctx(bindings=bind or {}, plugins=PluginDispatcher.of(plugins))
        nodes, last = self._build(ctx, entry)
        if last != out:
            nodes = [*nodes, _alias_node(last, out)]
        return System(nodes, policy=policy, halt_on_error=halt_on_error)

    async def run(
        self,
        value: A,
        *,
        bind: Mapping[str, Any] | None = None,
        budget: int | None = 100,
        plugins: Sequence[Plugin] = (),
    ) -> Outcome:
        """Compile and execute the flow on one input. The store, the seed fact, and the
        terminate condition (output produced, capped by `budget` supersteps; the default 100
        is a runaway guard, None lifts the cap) are derived, so the caller holds no tags.
        A selection policy or a lenient error discipline is the system's property: set it
        through .system(). Returns an Outcome: `.value`, `.ok`, `.reason`, `.errors`, and the
        full `.steps` trace.
        """
        dispatcher = PluginDispatcher.of(plugins)
        system = self.system(entry="in", out="out", bind=bind, plugins=dispatcher)
        return await system.run(
            {"in": value}, goal="out", budget=budget, plugins=dispatcher
        )

    async def stream(
        self,
        value: A,
        *,
        bind: Mapping[str, Any] | None = None,
        budget: int | None = 100,
        plugins: Sequence[Plugin] = (),
    ) -> AsyncIterator[StepReport]:
        """The streaming form of .run: yields each StepReport as the run unfolds."""
        dispatcher = PluginDispatcher.of(plugins)
        system = self.system(entry="in", out="out", bind=bind, plugins=dispatcher)
        async for report in system.stream(
            {"in": value}, goal="out", budget=budget, plugins=dispatcher
        ):
            yield report

    def __add__(self, other: Flow[B, C]) -> Flow[A, C]:
        return _Seq(self, other)

    def into(self: Flow[dict, Any], key: str) -> Flow[dict, dict]:
        """Thread a dict state past this flow: run it on the state, put its output under
        `key`, pass the other keys through unchanged. State-threading is composition, not a
        call parameter, so it works on any flow (an agent, an action, a nested system), and
        it is what lets stateless atoms fill loops, swarms, and chats."""
        return _Into(self, key)

    def merge(self: Flow[dict, Any]) -> Flow[dict, dict]:
        """Thread a dict state past this flow: fold the fields of its structured output into
        the state (a BaseModel output is dumped first). The output decides which keys change,
        which is what lets a handoff target ride inside the reply."""
        return _Merge(self)

    def loop(
        self: Flow[A, A],
        until: Callable[[A], bool] | Callable[[A, View], bool] | Predicate | str,
        *,
        budget: int | None = 100,
    ) -> Flow[A, A]:
        """Iterate the flow, feeding each round's output in as the next round's input, until
        `until` clears. `until` is a callable over the state (optionally the state and the
        view), a Condition or its `&`/`|`/`~` composition, or a state key (stop when state[key]
        is truthy). Each round runs the body in its own inner store as one outer superstep, so
        rounds are capped by the outer budget but a round itself is not; `budget` caps the
        supersteps inside one round (default 100, None lifts it).

        Example:
            revise.loop(until="approved")  # stop when state["approved"] is truthy
            revise.loop(until=lambda s: s["score"] >= 0.9)
        """
        fn, pred = state_predicate(until)
        return _Loop(self, fn, pred, budget)


class _Seq(Flow[Any, Any]):
    def __init__(self, left: Flow[Any, Any], right: Flow[Any, Any]) -> None:
        self._left = left
        self._right = right

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        la, lout = self._left._build(ctx, entry)
        ra, rout = self._right._build(ctx, lout)
        return [*la, *ra], rout


class _Into(Flow[dict, dict]):
    def __init__(self, inner: Flow[Any, Any], key: str) -> None:
        self._inner = inner
        self._key = key

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        nodes, reply = self._inner._build(ctx, entry)
        out = ctx.fresh("into")
        return [*nodes, _into_node(out, entry, reply, self._key)], out


class _Merge(Flow[dict, dict]):
    def __init__(self, inner: Flow[Any, Any]) -> None:
        self._inner = inner

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        nodes, reply = self._inner._build(ctx, entry)
        out = ctx.fresh("merge")
        return [*nodes, _merge_node(out, entry, reply)], out


class _Loop(Flow[Any, Any]):
    def __init__(
        self,
        body: Flow[Any, Any],
        until: Callable[[Any, View], bool],
        pred: Predicate | None,
        budget: int | None,
    ) -> None:
        self._body = body
        self._until = until
        self._pred = pred
        self._budget = budget

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        name = ctx.fresh("loop")
        addr = Loop(name)
        state = addr.state
        body_in, body_out = addr.body_in, addr.body_out
        inner = ctx.plugins.nested(name)
        body = self._body.system(
            entry=body_in, out=body_out, bind=ctx.bindings, plugins=inner
        )
        nodes = [
            _loop_iterate_node(
                name,
                body=body,
                body_in=body_in,
                body_out=body_out,
                entry=entry,
                state=state,
                until=self._until,
                pred=self._pred,
                budget=self._budget,
                plugins=inner,
            ),
            _loop_finish_node(
                name, state=state, out=name, until=self._until, pred=self._pred
            ),
        ]
        return nodes, name


class _Branch(Flow[Any, Any]):
    def __init__(
        self,
        select: Flow[Any, Any] | Callable[[Any, View], str],
        cases: dict[str, Flow[Any, Any]],
        select_spec: dict[str, Any],
    ) -> None:
        self._select = select
        self._cases = cases
        self._select_spec = select_spec

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        name = ctx.fresh("branch")
        out = name
        addr = Branch(name)
        ins = {k: addr.inlet(k) for k in self._cases}
        select = self._select
        nodes: list[Node] = []

        label_tag = ""
        classify: Callable[[Any, View], str] | None = None
        if isinstance(select, Flow):
            sel_nodes, label_tag = select._build(ctx, entry)
            nodes.extend(sel_nodes)
            route_reads = label_tag
        else:
            classify = select
            route_reads = entry

        nodes.append(
            _route_node(
                name,
                route_reads=route_reads,
                entry=entry,
                classify=classify,
                label_tag=label_tag,
                ins=ins,
                select_spec=self._select_spec,
                cases=list(self._cases),
            )
        )
        for k, case in self._cases.items():
            case_nodes, case_out = case._build(ctx, ins[k])
            nodes.extend(case_nodes)
            nodes.append(
                _alias_node(case_out, out, name=addr.join(k), kind=Kind.BRANCH_JOIN)
            )
        return nodes, out


def branch(
    select: Flow[A, str] | Callable[[A], str] | Callable[[A, View], str] | str,
    cases: dict[str, Flow[A, B]],
) -> Flow[A, B]:
    """Route the input to exactly one case by a label, then merge back to one output. `select`
    is a python callable A -> label (optionally (A, View) -> label), a state key (route by
    state[key], the declarative form), or a label-producing flow (an agent with labels=, when
    the route is the model's choice; an extra router step). All cases share input and output
    types, so the whole branch stays one typed arrow Flow[A, B].

    Example:
        kind = agent("kind", prompt="Classify the issue.", labels=["bug", "feature"])
        branch(kind, {"bug": triage, "feature": plan})
    """
    if isinstance(select, str):
        key = select
        spec: dict[str, Any] = {"by": "state", "key": key}
        return _Branch(lambda state, view: _pick(state, key), cases, spec)
    if not isinstance(select, Flow):
        return _Branch(bind_pred(select), cases, {"by": "callable"})
    return _Branch(select, cases, {"by": "flow"})


class _Gather(Flow[Any, Any]):
    def __init__(self, flows: tuple[Flow[Any, Any], ...]) -> None:
        self._flows = flows

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        out = ctx.fresh("gather")
        nodes: list[Node] = []
        srcs: list[str] = []
        for flow in self._flows:
            built, fout = flow._build(ctx, entry)
            nodes.extend(built)
            srcs.append(fout)
        return [*nodes, _collect_node(out, srcs, out)], out


def gather(*flows: Flow[A, B]) -> Flow[A, list[B]]:
    """Run several flows on the same input in parallel and collect their outputs into a list,
    joined when all complete. The n-ary form of *; follow it with a reducer (e.g. + majority)
    to fold the list into one value. Matches the dsl `gather` form.

    Example:
        gather(solver_a, solver_b, solver_c) + majority  # self-consistency vote
    """
    if not flows:
        raise ValueError("gather needs at least one flow")
    return _Gather(flows)


class _Nest(Flow[A, B]):
    def __init__(
        self,
        target: Flow[A, B] | System | Compilable,
        *,
        entry: str,
        out: str,
        terminate: Sequence[Terminate],
        budget: int | None,
    ) -> None:
        self._target = target
        self._entry = entry
        self._out = out
        self._terminate = terminate
        self._budget = budget

    def _build(self, ctx: Ctx, entry: str) -> tuple[list[Node], str]:
        name = ctx.fresh("nest")
        inner_entry, inner_out = self._entry, self._out
        inner = ctx.plugins.nested(name)
        target = self._target
        system = (
            target
            if isinstance(target, System)
            else target.system(
                entry=inner_entry, out=inner_out, bind=ctx.bindings, plugins=inner
            )
        )
        nest = _nest_node(
            name,
            system=system,
            entry=entry,
            inner_entry=inner_entry,
            inner_out=inner_out,
            budget=self._budget,
            terminate=self._terminate,
            plugins=inner,
        )
        return [nest], name


def nest(
    target: Flow[A, B] | System | Compilable,
    *,
    entry: str,
    out: str,
    terminate: Sequence[Terminate] = (),
    budget: int | None = 100,
) -> Flow[A, B]:
    """Run a whole sub-system as one typed arrow node: its own inner store, run to a goal,
    one fact out. The boundary is typed and composes; the interior stays opaque. `target` is
    a System or anything Compilable — a Flow, a Board, a third-party container exposing
    `.system(...)` — so this is how a goal-terminating Board (the blackboard surface) enters
    the arrow world, and how a flow nests another flow as an isolated unit. A Compilable
    target picks up the outer flow's run-scoped bindings and plugins; a System is already
    compiled, so they do not reach inside it. The inner run is the outer node's single
    superstep, so the outer budget cannot interrupt it; `budget` caps the inner supersteps
    instead (the default 100 is a runaway guard, None lifts it). The inner system runs under
    its own discipline: a strict one (the default) halts on its first error and the failure
    surfaces as this node's error fact, while a lenient one (halt_on_error=False) that still
    reaches `out` counts as success, its errors observable through on_error. The outer
    halt_on_error then decides whether the rest of the system continues. Named nest, not
    embed, to avoid the embeddings reading.

    Example:
        research = nest(board, entry="topic", out="report")
        pipeline = plan + research + write
    """
    return _Nest(target, entry=entry, out=out, terminate=terminate, budget=budget)
