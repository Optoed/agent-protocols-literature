import json

import httpx
import pytest
from fedotmas.engine.outcome import RunError
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec

from benchmarks.workflow_search.journal import Journal, JournalLLM
from benchmarks.workflow_search.recover import (
    RecoveryJournal,
    execute_with_length_failure,
    inherit_calls,
)


@pytest.mark.parametrize("finish_reason", ["length", "content_filter"])
async def test_only_truncation_becomes_failure_and_replay_is_free(
    tmp_path, finish_reason
):
    calls = []

    def respond(request):
        calls.append(request)
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "finish_reason": finish_reason,
                        "message": {"content": r"partial \boxed{1}"},
                    }
                ],
                "usage": {"cost": 0.01},
            },
        )

    spec = WorkflowSpec(
        nodes=(WorkflowNode(name="solve", prompt="Solve", inputs=("question",)),),
        output="solve",
    )
    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        for _ in range(2):
            llm = JournalLLM(journal, "fake", "search/task", "search_execution")
            if finish_reason == "length":
                assert await execute_with_length_failure(spec, "q", llm) == ""
            else:
                with pytest.raises(RunError):
                    await execute_with_length_failure(spec, "q", llm)
        assert len(calls) == 1
        assert journal.costs()["search_execution"]["known_usd"] == 0.01
    failures = list((tmp_path / "length_failures").glob("*.json"))
    assert len(failures) == (1 if finish_reason == "length" else 0)
    if failures:
        assert json.loads(failures[0].read_text())["quality"] == 0


async def test_network_failure_is_not_scored_as_wrong_answer(tmp_path):
    def fail(request):
        raise httpx.ReadTimeout("unknown payment")

    spec = WorkflowSpec(
        nodes=(WorkflowNode(name="solve", prompt="Solve", inputs=("question",)),),
        output="solve",
    )
    async with httpx.AsyncClient(transport=httpx.MockTransport(fail)) as client:
        journal = Journal(tmp_path, client)
        llm = JournalLLM(journal, "fake", "search/task", "search_execution")
        with pytest.raises(RunError):
            await execute_with_length_failure(spec, "q", llm)
    assert not (tmp_path / "length_failures").exists()
    assert journal.costs()["search_execution"]["unknown_cost_calls"] == 1


async def test_user_stopped_request_retries_without_losing_cost_history(tmp_path):
    source = tmp_path / "source"
    count = 0

    def respond(request):
        nonlocal count
        count += 1
        if count == 2:
            raise httpx.ReadTimeout("user stopped before response was recorded")
        return httpx.Response(200, json={"usage": {"cost": 0.01}, "choices": []})

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        original = Journal(source, client)
        await original.request("complete", {}, "search")
        with pytest.raises(httpx.ReadTimeout):
            await original.request("interrupted", {}, "search")
        before = {p.name: p.read_bytes() for p in (source / "calls").glob("*.json")}
        with pytest.raises(ValueError, match="explicit review"):
            inherit_calls(source, tmp_path / "rejected", False)
        target = tmp_path / "recovered"
        inherit_calls(source, target, True)
        journal = RecoveryJournal(target, client)
        await journal.request("complete", {}, "search")
        assert count == 2
        await journal.request("interrupted", {}, "search")
        assert count == 3
        costs = journal.costs()["search"]
        assert costs["calls"] == 3
        assert costs["known_usd"] == 0.02
        assert costs["unknown_cost_calls"] == 1
        assert before == {
            p.name: p.read_bytes() for p in (source / "calls").glob("*.json")
        }
        next_target = tmp_path / "recovered_again"
        inherit_calls(target, next_target, True)
        assert RecoveryJournal(next_target, client).costs() == journal.costs()
