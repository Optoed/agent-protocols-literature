import json

import httpx
from fedotmas.engine import Store
from fedotmas_llm import Call
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec, execute_workflow

from benchmarks.workflow_search.journal import Journal
from benchmarks.workflow_search.paired import experiment
from benchmarks.workflow_search.prepare_overnight import workflow_bank
from benchmarks.workflow_search.recover import execute_with_length_failure
from benchmarks.workflow_search.shared_roots import SharedRoots


def specs():
    single = WorkflowSpec(
        nodes=(WorkflowNode(name="solve", inputs=("question",), prompt="solve"),),
        output="solve",
    )
    swarm = WorkflowSpec(
        nodes=(
            WorkflowNode(name="left", inputs=("question",), prompt="solve"),
            WorkflowNode(name="right", inputs=("question",), prompt="solve"),
            WorkflowNode(name="review", inputs=("left", "right"), prompt="review"),
        ),
        output="review",
    )
    return single, swarm


async def test_root_reuse_preserves_two_independent_draws_and_changed_prompts(tmp_path):
    requests = []

    def respond(request):
        body = json.loads(request.content)
        requests.append(body)
        if body["messages"][0]["content"] == "review":
            assert "draw1" in body["messages"][1]["content"]
            assert "draw2" in body["messages"][1]["content"]
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "finish_reason": "stop",
                        "message": {"content": f"draw{len(requests)}"},
                    }
                ],
                "usage": {"cost": 0.01},
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        pool = SharedRoots(journal, "fake", "scope", "q", "shared_search")
        single, swarm = specs()
        assert (
            await execute_workflow(single, "q", pool.workflow(single.fingerprint))
            == "draw1"
        )
        assert (
            await execute_workflow(swarm, "q", pool.workflow(swarm.fingerprint))
            == "draw3"
        )
        assert len(requests) == 3
        await pool.workflow("different").complete(
            Call("changed prompt", "question:\nq"), Store().snapshot()
        )
        assert len(requests) == 4


async def test_shared_truncation_is_charged_once_and_scored_as_failure(tmp_path):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(
            200,
            json={
                "choices": [
                    {"finish_reason": "length", "message": {"content": "partial"}}
                ],
                "usage": {"cost": 0.01},
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        pool = SharedRoots(journal, "fake", "scope", "q", "shared_search")
        single, _ = specs()
        for key in ["a", "b"]:
            assert (
                await execute_with_length_failure(single, "q", pool.workflow(key)) == ""
            )
        assert len(requests) == 1
        assert journal.costs()["shared_search"]["known_usd"] == 0.01


async def test_paired_protocol_counts_and_resume_without_gold_leakage(tmp_path):
    requests = []

    def respond(request):
        assert "987654321" not in request.content.decode()
        requests.append(request)
        return httpx.Response(
            200,
            json={
                "choices": [
                    {"finish_reason": "stop", "message": {"content": r"\boxed{1}"}}
                ],
                "usage": {"cost": 0.01},
            },
        )

    single, swarm = specs()
    plan = {
        "model": "fake",
        "replicates": 2,
        "workflows": {
            s.fingerprint: s.model_dump(mode="json") for s in [single, swarm]
        },
        "search": [{"id": "s", "question": "q", "answer": "1"}],
        "test": [{"id": "t", "question": "new q", "answer": "987654321"}],
    }
    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        first = await experiment(plan, tmp_path, journal)
        count = len(requests)
        second = await experiment(plan, tmp_path, journal)
    assert first == second
    assert len(requests) == count == 16
    assert first["costs"]["independent_search"]["calls"] == 8
    assert first["costs"]["shared_search"]["calls"] == 6
    assert first["costs"]["test_execution"]["calls"] == 2
    assert all(r["test"]["shared"]["quality"] == 0 for r in first["replicates"])


async def test_six_workflows_three_repeats_and_two_domains(tmp_path):
    requests = []

    def respond(request):
        assert "987654321" not in request.content.decode()
        requests.append(request)
        return httpx.Response(
            200,
            json={
                "choices": [
                    {"finish_reason": "stop", "message": {"content": r"\boxed{1}"}}
                ],
                "usage": {"cost": 0.01},
            },
        )

    single, dual = specs()
    bank = workflow_bank(
        {
            "workflows": {
                s.fingerprint: s.model_dump(mode="json") for s in (single, dual)
            }
        }
    )
    assert len(bank) == 6
    plan = {
        "model": "fake",
        "replicates": 3,
        "workflows": {s.fingerprint: s.model_dump(mode="json") for s in bank.values()},
        "search": [
            {"id": f"s-{i}", "question": f"search {i}", "answer": "1", "domain": d}
            for i, d in enumerate(("algebra", "intermediate_algebra"))
        ],
        "test": [
            {
                "id": f"t-{i}",
                "question": f"test {i}",
                "answer": "987654321" if i else "1",
                "domain": d,
            }
            for i, d in enumerate(("algebra", "intermediate_algebra"))
        ],
    }
    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        result = await experiment(plan, tmp_path, journal)
        replay = await experiment(plan, tmp_path, journal)
    assert result == replay
    assert len(requests) == 168
    assert result["costs"]["independent_search"]["calls"] == 96
    assert result["costs"]["shared_search"]["calls"] == 66
    assert result["costs"]["test_execution"]["calls"] == 6
    for rep in result["replicates"]:
        assert set(rep["winners"].values()) == {single.fingerprint}
        assert len(rep["candidate_effects"]["shared"]) == 5
        assert rep["test"]["shared"]["by_domain"] == {
            "algebra": {"correct": 1, "count": 1},
            "intermediate_algebra": {"correct": 0, "count": 1},
        }
