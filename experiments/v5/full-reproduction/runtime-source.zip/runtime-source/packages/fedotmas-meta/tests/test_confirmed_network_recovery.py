import json

import httpx
import pytest

from benchmarks.workflow_search import recover_confirmed
from benchmarks.workflow_search.recover_confirmed import StableJournal, http_details


async def test_cooldown_preserves_attempts_and_exact_replay(tmp_path, monkeypatch):
    clock = [100.0]
    waits = []
    requested_at = []

    async def sleep(delay):
        waits.append(delay)
        clock[0] += delay

    monkeypatch.setattr(recover_confirmed.time, "monotonic", lambda: clock[0])
    monkeypatch.setattr(recover_confirmed.asyncio, "sleep", sleep)

    def respond(request):
        requested_at.append(clock[0])
        if len(requested_at) < 3:
            raise httpx.ReadError("network changed", request=request)
        return httpx.Response(
            200, json={"usage": {"cost": 0.01}, "answer": "unchanged"}
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = StableJournal(tmp_path, client)
        first = await journal.request("scope", {"model": "fake"}, "search")
        assert await journal.request("scope", {"model": "fake"}, "search") == first
        assert journal.costs()["search"]["unknown_cost_calls"] == 2
        assert journal.costs()["search"]["known_usd"] == 0.01
    assert waits == [30, 60]
    assert requested_at == [100, 130, 190]
    assert len(list((tmp_path / "interrupted_attempts/calls").glob("*.json"))) == 2


async def test_exhaustion_stops_after_three_attempts(tmp_path, monkeypatch):
    requests = []

    async def no_wait(self):
        pass

    monkeypatch.setattr(StableJournal, "wait_for_network", no_wait)

    def respond(request):
        requests.append(request)
        raise httpx.ReadError("lost", request=request)

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = StableJournal(tmp_path, client)
        with pytest.raises(httpx.ReadError):
            await journal.request("scope", {}, "search")
        assert journal.costs()["search"]["unknown_cost_calls"] == 3
    assert len(requests) == 3


@pytest.mark.parametrize("status", [401, 402, 403, 429, 503])
async def test_http_is_recorded_redacted_and_not_retried(tmp_path, status):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(
            status,
            json={
                "error": {
                    "code": status,
                    "message": "secret-value Bearer token sk-or-abcd",
                }
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = StableJournal(tmp_path, client, "secret-value")
        with pytest.raises(httpx.HTTPStatusError):
            await journal.request("scope", {}, "search")
        assert journal.costs()["search"]["unknown_cost_calls"] == 1
    assert len(requests) == 1
    record = json.loads(next((tmp_path / "calls").glob("*.json")).read_text())
    assert record["http_error"]["status_code"] == status
    assert record["http_error"]["message"] == "[redacted] [redacted] [redacted]"
    assert record["cost"] is None


async def test_cooldown_blocks_a_different_request(tmp_path, monkeypatch):
    clock = [10.0]
    waits = []

    async def sleep(delay):
        waits.append(delay)
        clock[0] += delay

    monkeypatch.setattr(recover_confirmed.time, "monotonic", lambda: clock[0])
    monkeypatch.setattr(recover_confirmed.asyncio, "sleep", sleep)

    def respond(request):
        assert clock[0] >= 40
        return httpx.Response(200, json={"usage": {"cost": 0}})

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = StableJournal(tmp_path, client)
        journal.pause_until = 40
        await journal.request("another-replicate", {}, "search")
    assert waits == [30]


def test_non_json_error_does_not_save_raw_body():
    assert http_details(httpx.Response(502, text="private html"), "") == {
        "status_code": 502
    }
