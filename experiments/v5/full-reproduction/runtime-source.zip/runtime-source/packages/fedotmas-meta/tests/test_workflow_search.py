import math
import random

import pytest
from fedotmas_meta.workflow import (
    InvalidProposal,
    WorkflowNode,
    WorkflowSpec,
    execute_workflow,
    propose_workflow,
)
from fedotmas_meta.workflow_search import (
    Evaluation,
    parent_weights,
    search_workflows,
    survivor_count,
)
from pydantic import ValidationError


def chain(size=1, label="solve"):
    return WorkflowSpec(
        nodes=tuple(
            WorkflowNode(
                name=f"step_{index}",
                prompt=f"{label} {index}",
                inputs=("question",)
                if index == 0
                else ("question", f"step_{index - 1}"),
            )
            for index in range(size)
        ),
        output=f"step_{size - 1}",
    )


@pytest.mark.parametrize(
    "nodes,output",
    [
        ([("a", ("later",))], "a"),
        ([("a", ("question",)), ("a", ("question",))], "a"),
        ([("question", ("question",))], "question"),
        ([("a", ("question",)), ("b", ("question",))], "b"),
        ([("a", ("question", "question"))], "a"),
        ([("a", ("question",))], "missing"),
    ],
)
def test_rejects_unexecutable_or_disconnected_graphs(nodes, output):
    with pytest.raises(ValidationError):
        WorkflowSpec(
            nodes=tuple(
                WorkflowNode(name=n, inputs=i, prompt="solve") for n, i in nodes
            ),
            output=output,
        )


def test_round_trip_and_prompt_sensitive_fingerprint():
    spec = chain(3)
    assert WorkflowSpec.model_validate_json(spec.model_dump_json()) == spec
    assert chain(3, "review").fingerprint != spec.fingerprint
    assert chain(3, "review").topology == spec.topology
    with pytest.raises(ValidationError):
        chain(7)


async def test_executes_fanout_and_merge_once_with_all_dependencies():
    spec = WorkflowSpec(
        nodes=(
            WorkflowNode(name="left", inputs=("question",), prompt="left"),
            WorkflowNode(name="right", inputs=("question",), prompt="right"),
            WorkflowNode(
                name="merge", inputs=("left", "right", "question"), prompt="merge"
            ),
        ),
        output="merge",
    )
    calls = []

    class Backend:
        async def complete(self, call, view):
            calls.append(call)
            if call.prompt == "merge":
                assert "left answer" in call.input and "right answer" in call.input
                assert "original question" in call.input
                return "final answer"
            return f"{call.prompt} answer"

    assert (
        await execute_workflow(spec, "original question", Backend()) == "final answer"
    )
    assert len(calls) == 3


async def test_runtime_errors_are_not_silent_wrong_answers():
    class Broken:
        async def complete(self, call, view):
            raise RuntimeError("provider unavailable")

    with pytest.raises(RuntimeError, match="provider unavailable"):
        await execute_workflow(chain(), "question", Broken())


async def test_structural_proposal_repair_and_no_hidden_test_data():
    calls = []

    class Proposer:
        async def complete(self, call, view):
            calls.append(call)
            return chain(1 if len(calls) == 1 else 2)

    child = await propose_workflow(chain(), "search-only feedback", Proposer())
    assert len(child.nodes) == 2 and len(calls) == 2
    assert "validation_error" in calls[1].input


async def test_halving_saves_evaluations_and_finishes_the_winner():
    async def propose(parent, feedback, index):
        return chain(index + 2)

    async def evaluate(spec, task):
        return Evaluation({1: 0.25, 2: 0.5, 3: 0.75, 4: 1.0}[len(spec.nodes)], 0.01)

    tasks = [str(index) for index in range(16)]
    full = await search_workflows(
        chain(), tasks, propose, evaluate, policy="full", rounds=1
    )
    half = await search_workflows(
        chain(), tasks, propose, evaluate, policy="halving", rounds=1
    )
    tied = await search_workflows(
        chain(), tasks, propose, evaluate, policy="tie_halving", rounds=1
    )
    assert tied.winner == half.winner
    assert len(tied.observations) == len(half.observations)
    assert half.winner == full.winner == chain(4)
    assert len(full.observations) == 64
    assert len(half.observations) == 44
    assert half.evaluation_cost == pytest.approx(0.44)
    assert full.evaluation_cost == pytest.approx(0.64)
    assert sum(k == half.winner.fingerprint for k, _ in half.observations) == 16


async def test_unknown_cost_remains_unknown_and_duplicates_are_not_reexecuted():
    calls = []

    async def propose(parent, feedback, index):
        return chain(2)

    async def evaluate(spec, task):
        calls.append((spec.fingerprint, task))
        return Evaluation(0.5, None)

    result = await search_workflows(
        chain(), ["a", "b"], propose, evaluate, policy="full", rounds=1, rungs=(1, 2)
    )
    assert len(calls) == len(set(calls)) == 4
    assert result.evaluation_cost is None
    assert sum(d.get("duplicate", False) for d in result.decisions) == 2


async def test_invalid_protocol_rejected_before_callbacks():
    async def fail(*args):
        raise AssertionError("should not call")

    with pytest.raises(ValueError, match="unique"):
        await search_workflows(
            chain(), ["a", "a"], fail, fail, policy="full", rungs=(2,)
        )
    with pytest.raises(ValueError, match="final rung"):
        await search_workflows(chain(), ["a"], fail, fail, policy="full", rungs=(2,))


@pytest.mark.parametrize(
    "quality,cost", [(math.nan, 0), (2, 0), (0, -1), (0, math.inf)]
)
def test_invalid_metrics_are_rejected(quality, cost):
    with pytest.raises(ValueError):
        Evaluation(quality, cost)


def test_parent_weights_match_aflow_mixture():
    assert parent_weights([0.9, 0.7, 0.5]) == pytest.approx(
        [0.7871832749778532, 0.11258620071487208, 0.10023052430727472]
    )
    assert parent_weights([0.5, 0.5]) == [0.5, 0.5]


async def test_bad_proposals_are_logged_without_losing_completed_work():
    async def propose(parent, feedback, index):
        raise InvalidProposal("bad graph")

    async def evaluate(spec, task):
        return Evaluation(0.5, 0.01)

    result = await search_workflows(
        chain(), ["a", "b"], propose, evaluate, policy="halving", rounds=1, rungs=(1, 2)
    )
    assert result.winner == chain()
    assert sum(d["event"] == "rejected_proposal" for d in result.decisions) == 3
    assert len(result.observations) == 2


def test_boundary_ties_are_kept_but_final_selection_is_single():
    assert survivor_count([1, 0.5, 0.5, 0], final=False, preserve_ties=True) == 3
    assert survivor_count([1, 0.5, 0.5, 0], final=False, preserve_ties=False) == 2
    assert survivor_count([0.5] * 4, final=False, preserve_ties=True) == 4
    assert survivor_count([0.5] * 4, final=True, preserve_ties=True) == 1
    with pytest.raises(ValueError):
        survivor_count([], final=False, preserve_ties=True)


async def test_tied_prefix_does_not_discard_later_winner():
    tasks = [str(i) for i in range(16)]
    order = tasks.copy()
    random.Random(0).shuffle(order)
    initial = chain()

    async def propose(parent, feedback, index):
        return chain(index + 2)

    async def evaluate(spec, task):
        if order.index(task) < 4:
            return Evaluation(0.0, 0.01)
        return Evaluation(1.0 if len(spec.nodes) == 4 else 0.0, 0.01)

    half = await search_workflows(
        initial, tasks, propose, evaluate, policy="halving", rounds=1
    )
    tied = await search_workflows(
        initial, tasks, propose, evaluate, policy="tie_halving", rounds=1
    )
    full = await search_workflows(
        initial, tasks, propose, evaluate, policy="full", rounds=1
    )
    assert half.quality == 0
    assert tied.winner == full.winner == chain(4)
    assert tied.quality == 0.75
    assert len(tied.observations) == len(full.observations)
    assert sum(k == tied.winner.fingerprint for k, _ in tied.observations) == 16
