import pytest

from benchmarks.workflow_search import awake


def test_keep_awake_restores_idle_policy_on_failure(monkeypatch):
    calls = []

    class Kernel:
        def SetThreadExecutionState(self, flags):
            calls.append(flags)
            return 1

    class Windll:
        kernel32 = Kernel()

    monkeypatch.setattr(awake.sys, "platform", "win32")
    monkeypatch.setattr(awake.ctypes, "windll", Windll(), raising=False)
    with pytest.raises(ValueError), awake.keep_awake(True):
        raise ValueError("experiment failure")
    assert calls == [0x80000001, 0x80000000]


def test_keep_awake_disabled_does_not_change_policy(monkeypatch):
    monkeypatch.delattr(awake.ctypes, "windll", raising=False)
    with awake.keep_awake(False):
        pass
