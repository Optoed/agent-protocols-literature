import copy
import json

import httpx
import pytest
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec

from benchmarks.workflow_search.answers import grade as strict_grade
from benchmarks.workflow_search.answers_v2 import grade
from benchmarks.workflow_search.confirmed import experiment, finalists, validate_plan
from benchmarks.workflow_search.recover_paired import TransportRecoveryJournal


@pytest.mark.parametrize(
    "value,reference",
    [
        ("a=-10/3", "-10/3"),
        ("a=8", "8"),
        ("50,000", "50000"),
        (r"\$50,000", "50000"),
        (r"x=\frac{-10}{3}", "-10/3"),
        ("-1,000.5", "-1000.5"),
        ("0", "0"),
    ],
)
def test_scalar_presentations(value, reference):
    assert grade(r"\boxed{" + value + "}", reference) == (1.0, "parsed")
    assert strict_grade(r"\boxed{a=8}", "8") == (0.0, "unparsed")


@pytest.mark.parametrize(
    "value",
    [
        "1,2,3",
        "50,00",
        "1234,567",
        "1,000,00",
        "a=b=8",
        "p+q=118",
        r"\pm8",
        r"\sqrt{64}",
        "[8]",
        "__import__('os')",
        "1/0",
    ],
)
def test_ambiguous_or_executable_presentations_are_rejected(value):
    assert grade(r"\boxed{" + value + "}", "8") == (0.0, "unparsed")


def plan():
    solve = WorkflowNode(name="solve", inputs=("question",), prompt="solve")
    single = WorkflowSpec(nodes=(solve,), output="solve")
    review = WorkflowSpec(
        nodes=(
            solve,
            WorkflowNode(name="review", inputs=("question", "solve"), prompt="review"),
        ),
        output="review",
    )
    return (
        {
            "model": "fake",
            "replicates": 2,
            "max_tokens": 8192,
            "temperature": 0.2,
            "near_tie_margin": 1,
            "workflows": {
                s.fingerprint: s.model_dump(mode="json") for s in (single, review)
            },
            "search": [
                {
                    "id": "s",
                    "question": "primary problem",
                    "answer": "1",
                    "domain": "algebra",
                }
            ],
            "confirmation": [
                {
                    "id": "c",
                    "question": "reserve problem",
                    "answer": "1",
                    "domain": "algebra",
                }
            ],
            "test": [
                {
                    "id": "t",
                    "question": "heldout problem",
                    "answer": "987654321",
                    "domain": "intermediate_algebra",
                }
            ],
        },
        single.fingerprint,
        review.fingerprint,
    )


async def test_confirmation_changes_winner_uses_fresh_draws_and_replays(tmp_path):
    data, single, review = plan()
    requests = []

    def respond(request):
        body = json.loads(request.content)
        prompt, question = (m["content"] for m in body["messages"])
        assert "987654321" not in request.content.decode()
        if "heldout problem" in question:
            assert list(tmp_path.glob("selection-*.json"))
        requests.append(body)
        answer = "0" if "reserve problem" in question and prompt == "solve" else "1"
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "finish_reason": "stop",
                        "message": {"content": r"\boxed{" + answer + "}"},
                    }
                ],
                "usage": {"cost": 0.01},
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = TransportRecoveryJournal(tmp_path, client, 2)
        result = await experiment(data, tmp_path, journal)
        replay = await experiment(data, tmp_path, journal)
    assert result == replay
    assert result["status"] == "completed"
    assert len(requests) == 28
    assert {k: v["calls"] for k, v in result["costs"].items()} == {
        "independent_search": 12,
        "shared_search": 4,
        "confirmation_search": 6,
        "test_execution": 6,
    }
    for rep in result["replicates"]:
        assert rep["winners"] == {
            "independent": review,
            "shared": single,
            "shared_confirm": review,
        }
        assert rep["test"]["independent"] == rep["test"]["shared_confirm"]
        assert rep["test"]["shared"]["quality"] == 0
    calls = [json.loads(p.read_text()) for p in (tmp_path / "calls").glob("*.json")]
    roots = [
        c
        for c in calls
        if c["category"] == "confirmation_search"
        and c["request"]["messages"][0]["content"] == "solve"
    ]
    assert len(roots) == 4
    assert len({c["identity"] for c in roots}) == 4


async def test_unique_clear_leader_skips_confirmation(tmp_path):
    data, single, _ = plan()
    data["replicates"] = 1
    data["search"].append(
        {"id": "s2", "question": "another primary problem", "answer": "1"}
    )

    def respond(request):
        body = json.loads(request.content)
        answer = "1" if body["messages"][0]["content"] == "solve" else "0"
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "finish_reason": "stop",
                        "message": {"content": r"\boxed{" + answer + "}"},
                    }
                ],
                "usage": {"cost": 0.01},
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        result = await experiment(
            data, tmp_path, TransportRecoveryJournal(tmp_path, client, 2)
        )
    assert result["status"] == "completed"
    assert "confirmation_search" not in result["costs"]
    assert set(result["replicates"][0]["winners"].values()) == {single}
    assert result["costs"]["test_execution"]["calls"] == 1


def test_finalist_boundary_and_confirmation_leakage_rejection():
    assert finalists({"a": 20, "b": 19, "c": 18}, 1) == ["a", "b"]
    data, _, _ = plan()
    data["confirmation"] = copy.deepcopy(data["test"])
    with pytest.raises(ValueError, match="leakage"):
        validate_plan(data)
