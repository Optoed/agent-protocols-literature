import hashlib

import httpx
import pytest
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec

from benchmarks.workflow_search.journal import Journal, write_json
from benchmarks.workflow_search.paired import experiment
from benchmarks.workflow_search.recover import inherit_calls
from benchmarks.workflow_search.recover_paired import (
    TransportRecoveryJournal,
    validate_source,
)


def response():
    return httpx.Response(
        200,
        json={
            "choices": [
                {"finish_reason": "stop", "message": {"content": r"\boxed{1}"}}
            ],
            "usage": {"cost": 0.01},
        },
    )


async def test_transport_retry_retains_unknown_cost_and_replays(tmp_path):
    calls = []

    def respond(request):
        calls.append(request)
        if len(calls) == 1:
            raise httpx.ReadError("connection lost", request=request)
        return response()

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = TransportRecoveryJournal(tmp_path, client, retries=1)
        first = await journal.request("test", {}, "search")
        assert await journal.request("test", {}, "search") == first
        costs = journal.costs()["search"]
    assert len(calls) == costs["calls"] == 2
    assert costs["known_usd"] == 0.01
    assert costs["unknown_cost_calls"] == 1
    assert len(list((tmp_path / "interrupted_attempts/calls").glob("*.json"))) == 1


@pytest.mark.parametrize("transport", [True, False])
async def test_retry_is_bounded_and_does_not_retry_http_status(tmp_path, transport):
    requests = []

    def respond(request):
        requests.append(request)
        if transport:
            raise httpx.ReadError("lost", request=request)
        return httpx.Response(402)

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = TransportRecoveryJournal(tmp_path, client, retries=1)
        with pytest.raises(httpx.HTTPError):
            await journal.request("test", {}, "search")
        assert len(requests) == (2 if transport else 1)
        assert journal.costs()["search"]["unknown_cost_calls"] == len(requests)


async def test_paired_recovery_only_pays_missing_calls_and_preserves_source(tmp_path):
    single = WorkflowSpec(
        nodes=(WorkflowNode(name="solve", inputs=("question",), prompt="solve"),),
        output="solve",
    )
    dual = WorkflowSpec(
        nodes=(
            WorkflowNode(name="left", inputs=("question",), prompt="solve"),
            WorkflowNode(name="right", inputs=("question",), prompt="solve"),
            WorkflowNode(name="review", inputs=("left", "right"), prompt="review"),
        ),
        output="review",
    )
    plan = {
        "model": "fake",
        "replicates": 2,
        "workflows": {s.fingerprint: s.model_dump(mode="json") for s in (single, dual)},
        "search": [{"id": "s", "question": "q", "answer": "1"}],
        "test": [{"id": "t", "question": "new q", "answer": "1"}],
    }
    requests = []

    def respond(request):
        requests.append(request)
        if len(requests) == 1:
            raise httpx.ReadError("source interrupted", request=request)
        return response()

    source, target = tmp_path / "source", tmp_path / "recovery"
    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        interrupted = await experiment(plan, source, Journal(source, client))
        assert interrupted["status"] == "interrupted"
        before = {
            str(p.relative_to(source)): p.read_bytes() for p in source.rglob("*.json")
        }
        inherit_calls(source, target, True)
        recovered = await experiment(
            plan, target, TransportRecoveryJournal(target, client, 0)
        )
    assert recovered["status"] == "completed"
    assert (
        len(requests) == 17
    )  # 16 successful logical calls plus the original failed attempt.
    assert sum(g["unknown_cost_calls"] for g in recovered["costs"].values()) == 1
    assert recovered["replicates"][1] == interrupted["replicates"][0]
    assert before == {
        str(p.relative_to(source)): p.read_bytes() for p in source.rglob("*.json")
    }


def test_recovery_rejects_changed_plan_code_or_active_source(tmp_path):
    source = tmp_path / "source"
    code = tmp_path / "runner.py"
    code.write_text("frozen")
    plan = tmp_path / "plan.json"
    plan.write_text("{}")
    protocol = {
        "plan_sha256": hashlib.sha256(plan.read_bytes()).hexdigest(),
        "source_hashes": {code.name: hashlib.sha256(code.read_bytes()).hexdigest()},
    }
    write_json(source / "protocol.json", protocol)
    write_json(source / "result.json", {"status": "interrupted"})
    write_json(
        tmp_path / "commands/source/run.json", {"status": "failed", "ended_utc": "done"}
    )
    assert validate_source(source, plan, tmp_path) == protocol
    plan.write_text('{"changed":true}')
    with pytest.raises(ValueError, match="plan changed"):
        validate_source(source, plan, tmp_path)
    plan.write_text("{}")
    code.write_text("changed")
    with pytest.raises(ValueError, match="source changed"):
        validate_source(source, plan, tmp_path)
    (source / "active.lock").write_text("123")
    with pytest.raises(ValueError, match="active lock"):
        validate_source(source, plan, tmp_path)
