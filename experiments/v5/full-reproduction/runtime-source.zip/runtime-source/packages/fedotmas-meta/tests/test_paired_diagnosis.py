from fractions import Fraction

import pytest

from benchmarks.workflow_search.diagnose_paired import diagnostic_value


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        (r"\boxed{a = -\frac{10}{3}}", Fraction(-10, 3)),
        (r"\boxed{\$50,000}", Fraction(50000)),
        (r"\boxed{1, 2, \frac{2}{3}}", None),
        (r"\boxed{1,23}", None),
        (r"\boxed{\pm 24}", None),
        (r"\boxed{14 + 2\sqrt{5}}", None),
        (r"\boxed{a = 1 = 2}", None),
    ],
)
def test_diagnostic_normalization_is_limited(text, expected):
    assert diagnostic_value(text) == expected
