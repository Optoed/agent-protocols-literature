import json
from types import SimpleNamespace

import httpx
import pytest
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec

from benchmarks.workflow_search.answers import boxed, grade, rational
from benchmarks.workflow_search.journal import Journal, archive_directory
from benchmarks.workflow_search.prepare import choose
from benchmarks.workflow_search.run import experiment, validate_tasks


@pytest.mark.parametrize(
    "text,reference",
    [
        (r"work \boxed{\frac{2}{4}}", "1/2"),
        (r"work \boxed{-0.5}", "-1/2"),
        (r"\boxed{1} corrected \boxed{2}", "2"),
    ],
)
def test_exact_answers(text, reference):
    assert grade(text, reference) == (1, "parsed")


def test_unsupported_answers_are_not_evaluated_as_code():
    assert rational("__import__('os').getcwd()") is None
    assert rational("1/0") is None
    assert boxed(r"\boxed{\frac{1}{2}") is None
    assert grade("the answer is 1", "1") == (0, "unparsed")
    with pytest.raises(ValueError):
        grade(r"\boxed{2}", r"\sqrt{4}")


async def test_resume_reuses_response_and_changed_request_is_rejected(tmp_path):
    calls = []

    def respond(request):
        calls.append(request)
        return httpx.Response(200, json={"usage": {"cost": 0.02}, "choices": []})

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        first = await journal.request("same", {"model": "fixture"}, "proposal")
        assert await journal.request("same", {"model": "fixture"}, "proposal") == first
        assert len(calls) == 1
        with pytest.raises(ValueError, match="configuration"):
            await journal.request("same", {"model": "different"}, "proposal")
        assert journal.costs()["proposal"]["known_usd"] == 0.02


async def test_uncertain_failure_is_preserved_and_not_paid_again(tmp_path):
    calls = []

    def fail(request):
        calls.append(request)
        raise httpx.ReadTimeout("fixture interrupted after sending")

    async with httpx.AsyncClient(transport=httpx.MockTransport(fail)) as client:
        journal = Journal(tmp_path, client)
        with pytest.raises(httpx.ReadTimeout):
            await journal.request("uncertain", {}, "search")
        with pytest.raises(RuntimeError, match="unsettled"):
            await journal.request("uncertain", {}, "search")
        assert len(calls) == 1
        assert journal.costs()["search"]["unknown_cost_calls"] == 1


def test_dataset_leakage_and_storage_preflight(tmp_path):
    row = {"id": "a", "question": "q", "answer": "1"}
    with pytest.raises(ValueError, match="leakage"):
        validate_tasks({"search": [row], "test": [row]})
    with pytest.raises(ValueError, match="safe identifier"):
        validate_tasks({"search": [row | {"id": "../escape"}], "test": [row]})
    with pytest.raises(ValueError, match="directory name"):
        archive_directory(tmp_path, "../escape")
    assert archive_directory(tmp_path, "run").is_dir()


@pytest.mark.parametrize("policy", ["full", "halving"])
async def test_complete_search_and_test_are_resumable_without_new_calls(
    tmp_path, policy
):
    counter = {"calls": 0, "proposals": 0}

    def respond(request):
        counter["calls"] += 1
        body = json.loads(request.content)
        if body.get("response_format"):
            counter["proposals"] += 1
            size = counter["proposals"] + 1
            spec = WorkflowSpec(
                nodes=tuple(
                    WorkflowNode(
                        name=f"n{i}",
                        prompt="Solve; output boxed answer",
                        inputs=("question",) if i == 0 else ("question", f"n{i - 1}"),
                    )
                    for i in range(size)
                ),
                output=f"n{size - 1}",
            )
            content = spec.model_dump_json()
        else:
            assert "987654321123" not in request.content.decode()
            content = r"\boxed{1}"
        return httpx.Response(
            200,
            json={
                "choices": [{"finish_reason": "stop", "message": {"content": content}}],
                "usage": {"cost": 0.001},
            },
        )

    data = {
        "search": [
            {"id": f"s{i}", "question": f"search {i}", "answer": "1"} for i in range(4)
        ],
        "test": [{"id": "t0", "question": "held out", "answer": "987654321123"}],
    }
    args = SimpleNamespace(
        generator="fake-generator",
        executor="fake-executor",
        policy=policy,
        rounds=1,
        rungs=[1, 2, 4],
        seed=1,
    )
    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        first = await experiment(args, tmp_path, data, journal)
        count = counter["calls"]
        second = await experiment(args, tmp_path, data, journal)
    assert counter["calls"] == count
    assert first == second
    assert first["test_quality"] == 0
    assert first["costs"]["proposal"]["calls"] == 3
    assert first["costs"]["test_execution"]["calls"] == 1


def test_data_sampling_rejects_truncation_and_filters_before_sampling():
    rows = [
        {
            "row_idx": i,
            "row": {"level": level, "problem": f"q{i}", "solution": solution},
        }
        for i, (level, solution) in enumerate(
            [
                ("Level 3", r"\boxed{1}"),
                ("Level 4", r"\boxed{1/2}"),
                ("Level 1", r"\boxed{3}"),
                ("Level 5", r"\boxed{\sqrt{2}}"),
            ]
        )
    ]
    assert {r["row_index"] for r in choose(rows, 2, 0)} == {0, 1}
    with pytest.raises(ValueError, match="enough"):
        choose(rows, 3, 0)
    with pytest.raises(ValueError, match="truncated"):
        choose([rows[0] | {"truncated_cells": ["solution"]}], 1, 0)
