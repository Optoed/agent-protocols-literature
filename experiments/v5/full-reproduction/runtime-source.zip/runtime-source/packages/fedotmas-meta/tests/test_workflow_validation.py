import json

import httpx
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec

from benchmarks.workflow_search.journal import Journal
from benchmarks.workflow_search.validate_bank import validate


async def test_validation_reuses_identical_workflow_and_hides_gold(tmp_path):
    calls = []
    spec = WorkflowSpec(
        nodes=(WorkflowNode(name="solve", inputs=("question",), prompt="Solve"),),
        output="solve",
    )
    plan = {
        "model": "fake",
        "workflows": {spec.fingerprint: spec.model_dump(mode="json")},
        "tasks": [
            {"id": "a", "question": "a", "answer": "987654321"},
            {"id": "b", "question": "b", "answer": "1"},
        ],
        "assignments": [{"full": spec.fingerprint, "tie_halving": spec.fingerprint}],
    }

    def respond(request):
        assert "987654321" not in request.content.decode()
        calls.append(json.loads(request.content))
        return httpx.Response(
            200,
            json={
                "choices": [
                    {"finish_reason": "stop", "message": {"content": r"\boxed{1}"}}
                ],
                "usage": {"cost": 0.01},
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
        journal = Journal(tmp_path, client)
        first = await validate(plan, tmp_path, journal)
        second = await validate(plan, tmp_path, journal)
    assert first == second
    assert first["status"] == "completed"
    assert first["workflows"][0]["quality"] == 0.5
    assert len(calls) == 2
    assert first["costs"]["validation_execution"]["known_usd"] == 0.02
