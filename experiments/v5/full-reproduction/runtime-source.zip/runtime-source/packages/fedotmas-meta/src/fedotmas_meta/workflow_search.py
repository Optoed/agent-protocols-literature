"""Compare full evaluation and successive halving during structural search."""

from __future__ import annotations

import math
import random
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from statistics import fmean
from typing import Literal

from fedotmas_meta.workflow import InvalidProposal, WorkflowSpec


@dataclass(frozen=True)
class Evaluation:
    quality: float
    cost: float | None

    def __post_init__(self) -> None:
        if not math.isfinite(self.quality) or not 0 <= self.quality <= 1:
            raise ValueError("quality must be finite and in [0, 1]")
        if self.cost is not None and (not math.isfinite(self.cost) or self.cost < 0):
            raise ValueError("cost must be nonnegative or unknown")


@dataclass(frozen=True)
class SearchResult:
    winner: WorkflowSpec
    quality: float
    candidates: dict[str, WorkflowSpec]
    observations: dict[tuple[str, str], Evaluation]
    decisions: tuple[dict, ...]

    @property
    def evaluation_cost(self) -> float | None:
        prices = [item.cost for item in self.observations.values()]
        return None if None in prices else sum(x for x in prices if x is not None)


Evaluator = Callable[[WorkflowSpec, str], Awaitable[Evaluation]]
Proposer = Callable[[WorkflowSpec, str, int], Awaitable[WorkflowSpec]]


def survivor_count(scores: Sequence[float], *, final: bool, preserve_ties: bool) -> int:
    """Preserve the boundary tie at intermediate rungs; final selection stays singular."""
    if not scores:
        raise ValueError("scores must be nonempty")
    if final:
        return 1
    keep = math.ceil(len(scores) / 2)
    if preserve_ties:
        while keep < len(scores) and scores[keep] == scores[keep - 1]:
            keep += 1
    return keep


def parent_weights(scores: Sequence[float]) -> list[float]:
    """AFlow's 0.3 uniform / 0.7 softmax mixture with alpha=0.2 on percent scores."""
    if not scores or any(not math.isfinite(s) or not 0 <= s <= 1 for s in scores):
        raise ValueError("parent scores must be nonempty, finite and in [0, 1]")
    weights = [math.exp(20 * (score - max(scores))) for score in scores]
    total = sum(weights)
    return [0.3 / len(scores) + 0.7 * weight / total for weight in weights]


async def search_workflows(
    initial: WorkflowSpec,
    tasks: Sequence[str],
    propose: Proposer,
    evaluate: Evaluator,
    *,
    policy: Literal["full", "halving", "tie_halving"],
    rounds: int = 2,
    offspring: int = 3,
    rungs: tuple[int, ...] = (4, 8, 16),
    seed: int = 0,
) -> SearchResult:
    """Search in cohorts, recording partial scores separately from complete scores.

    Evaluation cost excludes proposals; the experiment's provider ledger owns total cost.
    """
    if policy not in ("full", "halving", "tie_halving"):
        raise ValueError("unknown policy")
    if rounds < 1 or offspring < 1:
        raise ValueError("rounds and offspring must be positive")
    if not tasks or len(set(tasks)) != len(tasks):
        raise ValueError("tasks must be nonempty and unique")
    if not rungs or tuple(sorted(set(rungs))) != rungs or rungs[0] < 1:
        raise ValueError("rungs must be positive and strictly increasing")
    if rungs[-1] != len(tasks):
        raise ValueError("the final rung must cover every search task")
    order = list(tasks)
    rng = random.Random(seed)
    rng.shuffle(order)
    candidates = {initial.fingerprint: initial}
    observations: dict[tuple[str, str], Evaluation] = {}
    decisions: list[dict] = []

    async def score(candidate: WorkflowSpec, size: int) -> float:
        key = candidate.fingerprint
        for task in order[:size]:
            if (key, task) not in observations:
                observations[key, task] = await evaluate(candidate, task)
        return fmean(observations[key, task].quality for task in order[:size])

    parent = initial
    parent_quality = await score(parent, len(order))
    archive = {parent.fingerprint: parent_quality}
    for round_number in range(rounds):
        parents = sorted(archive, key=lambda key: (-archive[key], key))[:4]
        parent_key = rng.choices(
            parents, parent_weights([archive[k] for k in parents])
        )[0]
        parent, parent_quality = candidates[parent_key], archive[parent_key]
        cohort = [parent]
        feedback = (
            f"Parent quality is {parent_quality:.6f} on {len(order)} search tasks. "
            "Propose a different structural change. No test feedback is available."
        )
        for index in range(offspring):
            try:
                child = await propose(
                    parent, feedback, round_number * offspring + index
                )
                if child.topology == parent.topology:
                    raise InvalidProposal("proposer returned no structural change")
            except InvalidProposal as exc:
                decisions.append(
                    {
                        "event": "rejected_proposal",
                        "round": round_number,
                        "parent": parent.fingerprint,
                        "reason": str(exc),
                    }
                )
                continue
            key = child.fingerprint
            decisions.append(
                {
                    "event": "proposal",
                    "round": round_number,
                    "parent": parent.fingerprint,
                    "child": key,
                    "duplicate": key in candidates,
                }
            )
            if key not in candidates:
                candidates[key] = child
                cohort.append(child)
        stages = (len(order),) if policy == "full" else rungs
        for size in stages:
            ranked = []
            for candidate in cohort:
                quality = await score(candidate, size)
                ranked.append((quality, candidate))
                if size == len(order):
                    archive[candidate.fingerprint] = quality
            ranked.sort(
                key=lambda item: (-item[0], len(item[1].nodes), item[1].fingerprint)
            )
            keep = survivor_count(
                [q for q, _ in ranked],
                final=size == len(order),
                preserve_ties=policy == "tie_halving",
            )
            survivors = ranked[:keep]
            decisions.append(
                {
                    "event": "rung",
                    "round": round_number,
                    "size": size,
                    "scores": {c.fingerprint: q for q, c in ranked},
                    "survivors": [c.fingerprint for _, c in survivors],
                }
            )
            cohort = [candidate for _, candidate in survivors]
    winner = min(
        archive, key=lambda key: (-archive[key], len(candidates[key].nodes), key)
    )
    return SearchResult(
        candidates[winner], archive[winner], candidates, observations, tuple(decisions)
    )
