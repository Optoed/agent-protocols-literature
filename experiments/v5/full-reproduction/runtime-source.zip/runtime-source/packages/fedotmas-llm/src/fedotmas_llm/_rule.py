from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any

from fedotmas.engine.contract import View
from fedotmas.ext import Rule, render

from fedotmas_llm._llm import LLM, Call
from fedotmas_llm._tools import Tool

_BoundFn = Callable[[Any, View], Awaitable[Any]]


@dataclass
class PromptRule(Rule):
    """A blackboard rule whose body is a prompt over the LLM seam.
    It binds its backend via `llm` here or the run-scoped `bind={"llm": ...}`;
    reads/writes/when/meta behave exactly as on a code Rule.

    Example:
        draft = PromptRule(name="draft", reads="topic", writes="draft", prompt="Draft it.")
        check = PromptRule(name="check", reads="draft", writes="report", prompt="Review it.")
        board = blackboard(draft, check)
        out = await board.run({"topic": "tea"}, goal="report", bind={"llm": backend})
    """

    prompt: str | None = None
    input: str | None = None
    returns: Any = str
    llm: LLM | None = None
    tools: list[Tool] | None = None

    def _validate(self) -> None:
        if self.prompt is None:
            raise ValueError(f"rule {self.name!r}: prompt= is required")
        if self.fn is not None:
            raise ValueError(f"rule {self.name!r}: a prompt rule takes no fn=")
        self._check_common()

    def _body(self, bind: Mapping[str, Any]) -> _BoundFn:
        llm = self.llm or bind.get("llm")
        if llm is None:
            raise ValueError(
                f"rule {self.name!r} has no llm bound: pass llm= on the rule or the "
                'run-scoped default bind={"llm": ...}'
            )
        name, prompt, template, returns = (
            self.name,
            self.prompt,
            self.input,
            self.returns,
        )
        assert prompt is not None
        tools = tuple(self.tools or ())

        async def step(value: Any, view: View) -> Any:
            content = render(template, value, view, name) if template else value
            call = Call(prompt, content, returns=returns, tools=tools)
            return await llm.complete(call, view)

        return step
