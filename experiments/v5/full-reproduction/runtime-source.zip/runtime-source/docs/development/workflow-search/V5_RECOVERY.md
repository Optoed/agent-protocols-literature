# V5 recovery after VPN reconnection

On 2026-10-06 the user confirmed that AdGuard VPN reconnected during the interruption and authorized continued work. Windows records disconnection at 18:53:01.785 MSK and reconnection at 18:53:03.174; all three repeats retried at 18:53:02.091 and received HTTP failures before reconnection. The historical HTTP codes were not saved and cannot be recovered from those journals.

## Operational amendment

The new recover_confirmed runner calls the frozen confirmed.experiment without modifying it or its dependencies. The original plan, prompts, model, scoring, finalist rule, test sharing and original source hashes remain unchanged. The target is main-v5-confirmed-recovery2, inheriting main-v5-confirmed-recovery1, which inherited main-v5-confirmed.

Transport failures receive at most two retries, as before. Instead of waiting 1 and 2 seconds, wait 30 and 60 seconds. The cooldown is shared by all repeats so new calls wait while connectivity recovers; already pending calls are not cancelled. Two successful read-only API-key checks five seconds apart precede resumed paid work. These checks reduce an immediate restart risk but do not guarantee subsequent connectivity.

HTTP errors are not automatically retried. Their status code and limited, sanitized error code/message are saved on the failed call. Credentials and raw headers/HTML are not saved. Each failed transport attempt has a unique archive filename, even if two serialized failure records happen to be identical. No attempt is treated as free merely because its cost is unknown.

Source calls and their original statuses remain untouched. Completed calls replay by exact identity/request/category; the three outstanding HTTP failures are retried under the user's explicit continuation instruction. Historical failed attempts remain in interrupted_attempts/calls. Recovery accounting includes all ancestors: never add source and continuation totals together.

## Preflight

Source recovery1 has 700 completed calls, 298 completed workflow/task evaluations, known expenditure $0.3892533 and 12 attempts of unknown cost. Selection and test are unfinished. Recovery writes a separate manifest with the original protocol, source, inherited hashes, operational settings and runner hash.

340 package tests pass, including new tests for cooldown timing, the shared gate, exhausted retries, exact replay, error redaction, and HTTP 401/402/403/429/503 handling. Ruff and Ty pass. The unrelated PaperBench Windows failures and unavailable Deno from the V5 preflight remain outside this change; frozen experiment and frontend files are unchanged. Commands and outputs are under workflow-runs/commands/v5-network-recovery-*.
