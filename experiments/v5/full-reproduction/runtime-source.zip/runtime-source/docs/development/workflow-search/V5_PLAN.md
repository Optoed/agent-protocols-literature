# V5: shared screening with independent confirmation

Frozen before paid execution on 2026-10-06. V4 saved 34.29% of known search USD but lost 4.17 percentage points of official test accuracy. Its diagnostic exposed formatting errors and a five-way shared tie. V5 tests a specific revised selection procedure on fresh tasks; it does not replace V4 or prove that its failure was caused by ties.

## Registered comparison

The same six V4 workflow specifications and prompts are reused without edits: single, solve_review, solve_critique_revise, dual_review_v3, triple_review, plan_solve_review. This is adaptive allocation of evaluations within a fixed bank, not adaptive synthesis of graphs.

| Method | Primary selection tasks | Reserve selection tasks | Selection |
| --- | --- | --- | --- |
| independent | All six independently on 24 | All six independently on 8 | Highest correct count out of 32 |
| shared | All six with shared roots on 24 | None | Highest correct count out of 24 |
| shared_confirm | Reuses the same shared evaluations | Independently evaluate all finalists on 8 | Highest combined correct count out of 32 among finalists |

A finalist is at most one correct answer below the best shared score on the first 24 tasks. If there is only one finalist, skip confirmation and select it. Ties always prefer fewer nodes, then fingerprint. Confirmation does not use shared roots, full-mode answers, test answers, or performance estimates from V4. Confirmation scores have the same per-task weight as primary scores. Eligibility thresholds and tie-breaking never change after results.

Full and confirmed methods have the same 32-task selection pool. The raw shared ablation uses only the primary 24. Therefore their difference includes extra data and calls: this experiment cannot isolate independent confirmation from simply collecting more shared data. The comparison with full tests whether selective confirmation retains quality at lower search cost.

Independent and shared screening execute in alternate order by repeat parity. Three repeats run concurrently; provider model revisions, seeds and temporal routing are not controlled. Selection is saved before any test call in that repeat. Finalist confirmation uses new call scopes per task, workflow and repeat. Shared root reuse preserves separate draw ordinals for multiple solvers; downstream calls remain separate.

## Data and scoring

Use 80 new MATH Level 5 tasks with rational reference answers and no Asymptote diagrams: 24 primary selection (12 algebra, 12 intermediate algebra), 8 reserve (4 and 4), 48 test (24 and 24). Selection uses source train and held-out evaluation uses source test. Domains are interleaved. Exclude all 216 unique questions from previous experiments. Source response hashes and exclusions are recorded in V5_PROTOCOL.json, which is an exact copy of main-v5-confirmed-plan.json. Sampling seed is 20261026 + 10 * domain_index + phase_index, with phases primary, reserve, test. No resampling after quality is observed.

All modes use answers_v2: extract the final balanced boxed expression, remove an optional single-letter assignment and an escaped dollar currency prefix, normalize valid three-digit thousands grouping, then parse an exact rational number. No executable or symbolic evaluation, arbitrary equations, lists, radicals or plus/minus answers. Existing rational syntax is otherwise unchanged. Strict V4 quality is also saved for diagnostics; V4 records and official metrics remain unchanged. Length truncation is a task failure scored zero. Other errors interrupt the affected repeat and remain explicit.

The model is openai/gpt-4.1-nano, temperature 0.2, max_tokens 8192. Gold answers are only used by local scoring and never included in model requests. Three repeats 0/1/2 use fresh responses, with the same tasks across repeats. If modes choose the same workflow, its test execution is shared within that repeat and charged once. Test responses are fresh between repeats.

## Metrics and interpretation

Primary comparison: shared_confirm versus independent. Report mean test accuracy over three repeats, each repeat and both domains separately; search USD separately from test USD; selected workflows, finalist counts, confirmation effects and scorer differences. The registered positive descriptive signal is at least 20% savings in known search USD and mean test accuracy no lower than independent. Report unknown costs separately: this threshold is conditional on known costs when unresolved attempts exist.

The shared ablation measures the revised procedure against unconfirmed screening on this same new dataset and scorer. It is secondary. Do not change the primary comparator or criterion if the secondary result is more favorable. These are 48 unique test tasks, not 144 independent tasks. Three repeats, shared winners, small domains, one model and one fixed bank cannot establish statistical noninferiority, general superiority, or scientific novelty.

## Accounting and execution

Actual categories: independent_search, shared_search, confirmation_search, test_execution. Full strategy search cost is independent_search; raw shared is shared_search; confirmed is shared_search + confirmation_search. Shared search is paid only once and must not be summed twice in actual total expenditure. Shared test winners are charged once. Count calls and interrupted_attempts/calls, including every failed attempt with unknown cost.

Without truncation, full search uses 1536 calls, shared screening 792, confirmation at most 384. Confirmed search thus uses at most 1176 calls, 23.44% fewer than full; this is not a USD guarantee. At most three distinct selected graphs per repeat require 1440 test calls (the three largest have 4 + 3 + 3 nodes), so the registered upper bound is 4152 calls before retries. Expected spending is approximately $2 to $4, not a cutoff or guarantee. There is no per-stage or per-run monetary cutoff.

Use TransportRecoveryJournal with at most two automatic retries for each new transport failure, preserving all failed attempts. HTTP status and other errors are not retried. Completed responses replay without payment when the exact request/category matches; unresolved attempts block blind replay. The frozen protocol records source hashes and plan hash. Every command is recorded under workflow-runs/commands; results remain local in main-v5-confirmed. Keep-awake prevents automatic idle sleep while the recorder runs, but not lid closure, manual sleep or power loss.

The monitor reports every 20 minutes as requested, including unchanged state. It may read journals and progress, but cannot restart, change the protocol or initiate another hypothesis. Stop paid work after these three repeats and report the registered comparison, limitations and unresolved costs.

## Preflight record

All 331 package tests pass, including 21 new cases for normalized scoring, independent confirmation, skipped confirmation, exact replay and leakage rejection. Ruff and Ty pass (Ty checks packages, workflow_search and paperbench for Linux). Regenerating the plan from the saved snapshots reproduces every field except its registration timestamp; its committed copy matches byte-for-byte. Available OpenRouter balance before launch was $7.194104304; the balance request performed no completion calls.

The full repository test invocation reports 347 passed and 9 failures in unrelated PaperBench PDF/worker tests on this Windows host, also outside the sandbox. Deno is unavailable on the current PATH, so frontend verification was not rerun; no frontend files changed. Command outputs are preserved under workflow-runs/commands/v5-confirmed-*. No paid diagnostic or pilot was run before freezing this protocol.
