"""Freeze a six-workflow comparison on unseen Level 5 tasks from two MATH domains."""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec

from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.prepare import choose
from benchmarks.workflow_search.run import validate_tasks


def workflow_bank(previous: dict) -> dict[str, WorkflowSpec]:
    single, dual = sorted(
        (WorkflowSpec.model_validate(s) for s in previous["workflows"].values()),
        key=lambda s: len(s.nodes),
    )
    solve = single.nodes[0]
    review = "Check the proposed solution against the original problem, correct any errors, and end with the exact rational answer in \\boxed{...}."
    critique = "Audit the proposed solution against the original problem. Identify specific logical or arithmetic errors and suggest corrections. If correct, explain the checks."
    return {
        "single": single,
        "solve_review": WorkflowSpec(
            nodes=(
                solve,
                WorkflowNode(
                    name="review", inputs=("question", "solve"), prompt=review
                ),
            ),
            output="review",
        ),
        "solve_critique_revise": WorkflowSpec(
            nodes=(
                solve,
                WorkflowNode(
                    name="critique", inputs=("question", "solve"), prompt=critique
                ),
                WorkflowNode(
                    name="revise",
                    inputs=("question", "solve", "critique"),
                    prompt=review,
                ),
            ),
            output="revise",
        ),
        "dual_review_v3": dual,
        "triple_review": WorkflowSpec(
            nodes=(
                *(
                    WorkflowNode(
                        name=f"solve_{i}", inputs=("question",), prompt=solve.prompt
                    )
                    for i in range(3)
                ),
                WorkflowNode(
                    name="review",
                    inputs=("question", "solve_0", "solve_1", "solve_2"),
                    prompt="Compare the three independent solutions against the original problem. Verify the reasoning instead of blindly voting, resolve disagreements, and end with the exact rational answer in \\boxed{...}.",
                ),
            ),
            output="review",
        ),
        "plan_solve_review": WorkflowSpec(
            nodes=(
                WorkflowNode(
                    name="plan",
                    inputs=("question",),
                    prompt="Develop a precise mathematical plan for solving the problem. Identify useful transformations and checks. Do not claim a final answer without solving.",
                ),
                WorkflowNode(
                    name="solve", inputs=("question", "plan"), prompt=solve.prompt
                ),
                WorkflowNode(
                    name="review", inputs=("question", "solve"), prompt=review
                ),
            ),
            output="review",
        ),
    }


def build_plan(root: Path) -> dict:
    sources = {
        "algebra": root / "math-algebra-data-v1",
        "intermediate_algebra": root / "math-intermediate-level5-v1",
    }
    used = set()
    exclusion_hashes = {}
    for raw in sources.values():
        path = raw / "tasks.json"
        previous = json.loads(path.read_text(encoding="utf-8"))
        exclusion_hashes[str(path.relative_to(root))] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
        used.update(
            t["question"].strip()
            for part in ("pilot", "search", "test")
            for t in previous[part]
        )
    for name in ("main-v2-ties-validation-plan.json", "main-v3-paired-plan.json"):
        path = root / name
        previous = json.loads(path.read_text(encoding="utf-8"))
        exclusion_hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        parts = ("tasks",) if "tasks" in previous else ("search", "test")
        used.update(t["question"].strip() for part in parts for t in previous[part])
    bank = workflow_bank(previous)
    plan: dict = {
        "registered_utc": datetime.now(timezone.utc).isoformat(),
        "kind": "six-fixed-workflows-shared-root-evaluation-not-adaptive-graph-search",
        "model": "openai/gpt-4.1-nano",
        "replicates": 3,
        "max_tokens": 8192,
        "temperature": 0.2,
        "sampling_seed": 20261009,
        "source_hashes": {},
        "exclusion_source_hashes": exclusion_hashes,
        "exclusion_count": len(used),
        "selection": "highest search accuracy; ties prefer fewer nodes then fingerprint",
        "search": [],
        "test": [],
        "workflows": {s.fingerprint: s.model_dump(mode="json") for s in bank.values()},
        "labels": {s.fingerprint: label for label, s in bank.items()},
        "expected_search_calls": {"independent": 1152, "shared": 792},
        "maximum_test_calls": 1008,
        "cost_estimate_usd": [2, 5],
        "monetary_cutoff": None,
    }
    for domain_index, (domain, raw) in enumerate(sources.items()):
        manifest = json.loads(
            (raw / "source-manifest.json").read_text(encoding="utf-8")
        )
        for split_index, (part, split, size) in enumerate(
            (("search", "train", 12), ("test", "test", 24))
        ):
            rows = []
            for path in sorted(raw.glob(f"{split}-*.json")):
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                if digest != manifest["pages"][path.name]["sha256"]:
                    raise ValueError("source snapshot changed")
                plan["source_hashes"][str(path.relative_to(root))] = digest
                rows.extend(
                    r
                    for r in json.loads(path.read_text(encoding="utf-8"))["rows"]
                    if r["row"]["problem"].strip() not in used
                )
            selected = choose(
                rows, size, 20261009 + 10 * domain_index + split_index, minimum_level=5
            )
            plan[part].extend(
                t | {"id": f"math-{domain}-{split}-{t['row_index']}", "domain": domain}
                for t in selected
            )
            used.update(t["question"].strip() for t in selected)
    for part in ("search", "test"):
        half = len(plan[part]) // 2
        plan[part] = [
            t
            for pair in zip(plan[part][:half], plan[part][half:], strict=True)
            for t in pair
        ]
    validate_tasks(plan)
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    args = parser.parse_args()
    path = args.runs / "main-v4-overnight-plan.json"
    if path.exists():
        parser.error("plan already exists")
    plan = build_plan(args.runs)
    write_json(path, plan)
    print(
        json.dumps(
            {
                "plan": str(path),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "excluded": plan["exclusion_count"],
                "search": len(plan["search"]),
                "test": len(plan["test"]),
                "workflows": len(plan["workflows"]),
                "replicates": plan["replicates"],
            }
        )
    )


if __name__ == "__main__":
    main()
