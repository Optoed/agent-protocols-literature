"""Fetch an immutable public AFlow snapshot and record file hashes."""

import argparse
import hashlib
import io
import json
import urllib.request
import zipfile
from pathlib import Path

REVISION = "3f457218fc716093fe53f6df8a5d5e6379d66346"
SOURCE = f"https://codeload.github.com/FoundationAgents/AFlow/zip/{REVISION}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must be a new directory")
    request = urllib.request.Request(SOURCE, headers={"User-Agent": "FEDOT-research"})
    with urllib.request.urlopen(request, timeout=60) as response:
        archive = response.read()
    root = args.output.resolve()
    files = {}
    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
        for item in bundle.infolist():
            if item.is_dir():
                continue
            relative = Path(*Path(item.filename).parts[1:])
            target = (root / relative).resolve()
            if not target.is_relative_to(root):
                raise ValueError("archive entry escapes the output directory")
            data = bundle.read(item)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            files[relative.as_posix()] = hashlib.sha256(data).hexdigest()
    manifest = {
        "repository": "https://github.com/FoundationAgents/AFlow",
        "revision": REVISION,
        "source": SOURCE,
        "archive_sha256": hashlib.sha256(archive).hexdigest(),
        "archive_bytes": len(archive),
        "files": files,
    }
    (root / "source-manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(
        json.dumps({"revision": REVISION, "bytes": len(archive), "files": len(files)})
    )


if __name__ == "__main__":
    main()
