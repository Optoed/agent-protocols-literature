"""Freeze a small rational-answer MATH algebra subset before any model evaluation."""

import argparse
import hashlib
import json
import random
import urllib.parse
import urllib.request
from pathlib import Path

from benchmarks.workflow_search.answers import boxed, rational
from benchmarks.workflow_search.journal import archive_directory, write_json

DATASET = "EleutherAI/hendrycks_math"


def choose(
    rows: list[dict], size: int, seed: int, minimum_level: int = 3
) -> list[dict]:
    eligible = []
    for item in rows:
        if item.get("truncated_cells"):
            raise ValueError("dataset server truncated a source cell")
        row = item["row"]
        answer = boxed(row["solution"])
        if row["level"] not in {f"Level {level}" for level in range(minimum_level, 6)}:
            continue
        if "[asy]" in row["problem"] or answer is None or rational(answer) is None:
            continue
        eligible.append(
            {
                "row_index": item["row_idx"],
                "question": row["problem"],
                "answer": answer,
                "level": row["level"],
            }
        )
    if len(eligible) < size:
        raise ValueError("not enough eligible tasks; do not relax filters silently")
    return random.Random(seed).sample(eligible, size)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--archive-root",
        type=Path,
        default=Path(__file__).resolve().parents[3] / "workflow-runs",
    )
    parser.add_argument("--name", default="math-algebra-data-v1")
    parser.add_argument("--seed", type=int, default=20261004)
    parser.add_argument(
        "--config", choices=("algebra", "intermediate_algebra"), default="algebra"
    )
    parser.add_argument("--minimum-level", choices=(3, 4, 5), type=int, default=3)
    args = parser.parse_args()
    directory = archive_directory(args.archive_root, args.name)
    if any(directory.iterdir()):
        parser.error("data directory must be empty; snapshots are immutable")
    manifest = {
        "dataset": DATASET,
        "config": args.config,
        "seed": args.seed,
        "sampling": f"uniform among rational-answer levels {args.minimum_level}-5 without asy diagrams",
        "scope": f"MATH {args.config} subset, not the complete MATH benchmark",
        "snapshot": "datasets-server response content hashes; not a pinned HF revision",
        "pages": {},
    }
    selected = {}
    for split, size in (("train", 24), ("test", 32)):
        rows = []
        offset = 0
        while True:
            query = urllib.parse.urlencode(
                {
                    "dataset": DATASET,
                    "config": args.config,
                    "split": split,
                    "offset": offset,
                    "length": 100,
                }
            )
            url = "https://datasets-server.huggingface.co/rows?" + query
            request = urllib.request.Request(
                url, headers={"User-Agent": "FEDOT-research"}
            )
            with urllib.request.urlopen(request, timeout=60) as response:
                content = response.read()
            page = json.loads(content)
            if not page["rows"]:
                raise ValueError("unexpected empty dataset page")
            name = f"{split}-{offset}.json"
            (directory / name).write_bytes(content)
            manifest["pages"][name] = {
                "sha256": hashlib.sha256(content).hexdigest(),
                "url": url,
            }
            rows.extend(page["rows"])
            offset += len(page["rows"])
            if offset >= page["num_rows_total"]:
                break
        selected[split] = [
            row | {"id": f"math-{args.config}-{split}-{row['row_index']}"}
            for row in choose(
                rows, size, args.seed + (split == "test"), args.minimum_level
            )
        ]
    tasks = {
        "source": manifest,
        "pilot": selected["train"][:8],
        "search": selected["train"][8:],
        "test": selected["test"],
    }
    questions = [row["question"].strip() for rows in selected.values() for row in rows]
    if len(set(questions)) != len(questions):
        raise ValueError(
            "source contains duplicate selected questions; do not resample silently"
        )
    write_json(directory / "tasks.json", tasks)
    write_json(directory / "source-manifest.json", manifest)
    print(
        json.dumps(
            {
                "tasks": str(directory / "tasks.json"),
                "pilot": 8,
                "search": 16,
                "test": 32,
            }
        )
    )


if __name__ == "__main__":
    main()
