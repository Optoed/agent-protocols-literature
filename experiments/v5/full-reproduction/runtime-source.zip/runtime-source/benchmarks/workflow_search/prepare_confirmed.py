"""Freeze new, disjoint tasks for full evaluation and independently confirmed shared screening."""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from benchmarks.workflow_search.confirmed import validate_plan
from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.prepare import choose


def build_plan(root: Path) -> dict:
    previous_path = root / "main-v4-overnight-plan.json"
    previous = json.loads(previous_path.read_text(encoding="utf-8"))
    exclusions = previous["exclusion_source_hashes"] | {
        previous_path.name: hashlib.sha256(previous_path.read_bytes()).hexdigest()
    }
    used = set()
    for name, digest in exclusions.items():
        path = root / name
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError("exclusion source changed")
        data = json.loads(path.read_text(encoding="utf-8"))
        for part in ("pilot", "search", "test", "tasks"):
            used.update(t["question"].strip() for t in data.get(part, []))
    if len(used) != 216:
        raise ValueError("unexpected exclusion count")
    plan: dict = {
        "registered_utc": datetime.now(timezone.utc).isoformat(),
        "kind": "fixed-bank-shared-screening-independent-confirmation",
        "model": previous["model"],
        "replicates": 3,
        "max_tokens": 8192,
        "temperature": 0.2,
        "sampling_seed": 20261026,
        "near_tie_margin": 1,
        "source_hashes": {},
        "exclusion_source_hashes": exclusions,
        "exclusion_count": len(used),
        "workflows": previous["workflows"],
        "labels": previous["labels"],
        "search": [],
        "confirmation": [],
        "test": [],
        "scorer": "answers_v2: scalar rational, single-letter assignment, currency, grouped thousands",
        "selection": "Full uses 32 tasks. Shared uses 24. Confirmed adds 8 independent tasks for all candidates within one correct answer of shared best, if more than one. Highest combined correct wins, ties fewer nodes then fingerprint.",
        "expected_search_calls": {"independent_search": 1536, "shared_search": 792},
        "maximum_confirmation_calls": 384,
        "maximum_test_calls": 1440,
        "cost_estimate_usd": [2, 4],
        "monetary_cutoff": None,
    }
    sources = {
        "algebra": "math-algebra-data-v1",
        "intermediate_algebra": "math-intermediate-level5-v1",
    }
    for domain_index, (domain, name) in enumerate(sources.items()):
        raw = root / name
        manifest = json.loads(
            (raw / "source-manifest.json").read_text(encoding="utf-8")
        )
        for phase_index, (part, split, size) in enumerate(
            (
                ("search", "train", 12),
                ("confirmation", "train", 4),
                ("test", "test", 24),
            )
        ):
            rows = []
            for path in sorted(raw.glob(f"{split}-*.json")):
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                if digest != manifest["pages"][path.name]["sha256"]:
                    raise ValueError("source snapshot changed")
                plan["source_hashes"][str(path.relative_to(root))] = digest
                rows.extend(
                    r
                    for r in json.loads(path.read_text(encoding="utf-8"))["rows"]
                    if r["row"]["problem"].strip() not in used
                )
            selected = choose(
                rows, size, 20261026 + 10 * domain_index + phase_index, minimum_level=5
            )
            plan[part].extend(
                t | {"id": f"math-{domain}-{split}-{t['row_index']}", "domain": domain}
                for t in selected
            )
            used.update(t["question"].strip() for t in selected)
    for part in ("search", "confirmation", "test"):
        half = len(plan[part]) // 2
        plan[part] = [
            t
            for pair in zip(plan[part][:half], plan[part][half:], strict=True)
            for t in pair
        ]
    validate_plan(plan)
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    args = parser.parse_args()
    path = args.runs / "main-v5-confirmed-plan.json"
    if path.exists():
        parser.error("plan already exists")
    plan = build_plan(args.runs)
    write_json(path, plan)
    print(
        json.dumps(
            {
                "plan": str(path),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "excluded": plan["exclusion_count"],
                **{
                    part: len(plan[part]) for part in ("search", "confirmation", "test")
                },
            }
        )
    )


if __name__ == "__main__":
    main()
