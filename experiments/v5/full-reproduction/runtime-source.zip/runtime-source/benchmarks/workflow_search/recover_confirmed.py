"""Resume frozen V5 with a shared transport cooldown and safe HTTP diagnostics."""

import argparse
import asyncio
import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import httpx
from dotenv import dotenv_values

from benchmarks.workflow_search.confirmed import experiment, validate_plan
from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.recover import inherit_calls
from benchmarks.workflow_search.recover_paired import (
    TransportRecoveryJournal,
    validate_source,
)


def http_details(response: httpx.Response, secret: str) -> dict:
    details: dict = {"status_code": response.status_code}
    try:
        error = response.json().get("error", {})
    except (ValueError, AttributeError):
        return details
    if not isinstance(error, dict):
        return details
    for field in ("code", "message"):
        value = error.get(field)
        if isinstance(value, (str, int)):
            text = str(value)
            if secret:
                text = text.replace(secret, "[redacted]")
            text = re.sub(r"(?i)bearer\s+\S+|sk-[A-Za-z0-9_-]+", "[redacted]", text)
            details[field] = text[:1000]
    return details


class StableJournal(TransportRecoveryJournal):
    def __init__(self, directory: Path, client: httpx.AsyncClient, secret: str = ""):
        super().__init__(directory, client, retries=0)
        self.secret = secret
        self.pause_until = 0.0

    async def wait_for_network(self):
        while (delay := self.pause_until - time.monotonic()) > 0:
            await asyncio.sleep(delay)

    async def request(self, identity: str, body: dict, category: str) -> dict:
        path = (
            self.directory
            / "calls"
            / f"{hashlib.sha256(identity.encode()).hexdigest()}.json"
        )
        for attempt in range(3):
            await self.wait_for_network()
            try:
                return await super().request(identity, body, category)
            except httpx.HTTPStatusError as exc:
                record = json.loads(path.read_text(encoding="utf-8"))
                record["http_error"] = http_details(exc.response, self.secret)
                write_json(path, record)
                print(
                    json.dumps(
                        {
                            "http_error": identity,
                            "status_code": exc.response.status_code,
                        }
                    ),
                    flush=True,
                )
                raise
            except httpx.TransportError:
                if attempt == 2:
                    raise
                content = path.read_bytes()
                target = (
                    self.directory
                    / "interrupted_attempts"
                    / "calls"
                    / f"{hashlib.sha256(content).hexdigest()}-{uuid4().hex}.json"
                )
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                if target.read_bytes() != content:
                    raise OSError("failed to preserve interrupted attempt")
                path.unlink()
                delay = 30 * (attempt + 1)
                self.pause_until = max(self.pause_until, time.monotonic() + delay)
                print(
                    json.dumps(
                        {
                            "transport_retry": identity,
                            "retry_number": attempt + 1,
                            "cooldown_seconds": delay,
                            "prior_cost": "unknown",
                        }
                    ),
                    flush=True,
                )
        raise AssertionError("unreachable")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    if Path(args.name).name != args.name or args.name in ("", ".", ".."):
        parser.error("name must be one directory name")
    protocol = validate_source(source, args.plan, Path(__file__).resolve().parents[2])
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    validate_plan(plan)
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing API key")
    directory = source.parent / args.name
    directory.mkdir(exist_ok=False)
    inherited = inherit_calls(source, directory, True)
    for original in (source / "calls").glob("*.json"):
        content = original.read_bytes()
        record = json.loads(content)
        target = (
            directory / "calls" / original.name
            if record["status"] == "completed"
            else directory
            / "interrupted_attempts"
            / "calls"
            / f"{hashlib.sha256(content).hexdigest()}.json"
        )
        if content != target.read_bytes():
            raise OSError("inherited call differs")
    write_json(directory / "protocol.json", protocol)
    write_json(
        directory / "recovery.json",
        {
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "source": str(source),
            "original_protocol": protocol,
            "inherited_calls": inherited,
            "retry_interrupted": True,
            "transport_retries": 2,
            "shared_cooldown_seconds": [30, 60],
            "http_retries": 0,
            "amendment": "Only operational behavior changes: pause new requests across repeats after transport failure; preserve HTTP status and sanitized error message. Selection, tasks, prompts, model and scoring stay frozen.",
            "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        },
    )
    lock = directory / "active.lock"
    with lock.open("x", encoding="utf-8") as f:
        f.write(str(os.getpid()))

    async def resume():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = StableJournal(directory, client, key)
            try:
                for check in range(2):
                    readiness = await client.get("https://openrouter.ai/api/v1/key")
                    if not readiness.is_success:
                        write_json(
                            directory / "readiness.json", http_details(readiness, key)
                        )
                        raise RuntimeError("read-only API readiness failed")
                    if check == 0:
                        await asyncio.sleep(5)
                result = await experiment(plan, directory, journal)
                result["recovered_from"] = str(source)
                write_json(directory / "result.json", result)
                print(json.dumps(result), flush=True)
                if result["errors"]:
                    raise RuntimeError(
                        "recovery interrupted; inspect preserved diagnostics"
                    )
            finally:
                write_json(directory / "costs.json", journal.costs())

    try:
        asyncio.run(resume())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
