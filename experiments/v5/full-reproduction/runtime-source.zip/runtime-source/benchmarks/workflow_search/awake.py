"""Prevent automatic Windows idle sleep only while a recorded experiment is running."""

import ctypes
import sys
from contextlib import contextmanager


@contextmanager
def keep_awake(enabled: bool):
    setter = None
    if enabled and sys.platform == "win32":
        setter = ctypes.windll.kernel32.SetThreadExecutionState
        if not setter(0x80000001):
            raise OSError("could not prevent automatic idle sleep")
    try:
        yield
    finally:
        if setter is not None:
            setter(0x80000000)
