"""Continue an interrupted search, counting truncated execution as a task failure."""

import argparse
import asyncio
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import httpx
from dotenv import dotenv_values
from fedotmas.engine.outcome import RunError
from fedotmas_llm import LLM
from fedotmas_meta.workflow import WorkflowSpec, execute_workflow

from benchmarks.workflow_search import run
from benchmarks.workflow_search.journal import Journal, JournalLLM, write_json


class RecoveryJournal(Journal):
    def costs(self) -> dict:
        totals = super().costs()
        interrupted = Journal(self.directory / "interrupted_attempts", self.client)
        for category, group in interrupted.costs().items():
            target = totals.setdefault(category, dict.fromkeys(group, 0))
            for key, value in group.items():
                target[key] += value
        return totals


def inherit_calls(source: Path, directory: Path, retry_interrupted: bool) -> dict:
    paths = sorted((source / "calls").glob("*.json"))
    records = [(path, json.loads(path.read_text(encoding="utf-8"))) for path in paths]
    if not retry_interrupted and any(r["status"] != "completed" for _, r in records):
        raise ValueError("unsettled source call requires explicit review")
    inherited = {}
    for path, record in records:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        target = directory / "calls" / path.name
        if record["status"] != "completed":
            target = directory / "interrupted_attempts" / "calls" / f"{digest}.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        inherited[path.name] = digest
    for path in (source / "interrupted_attempts" / "calls").glob("*.json"):
        target = directory / "interrupted_attempts" / "calls" / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    return inherited


async def execute_with_length_failure(
    spec: WorkflowSpec, question: str, llm: LLM
) -> str:
    try:
        return await execute_workflow(spec, question, llm)
    except RunError as exc:
        if not isinstance(llm, JournalLLM):
            raise
        message = "incomplete provider answer; charged response is preserved"
        if not exc.errors or any(str(error.value) != message for error in exc.errors):
            raise
        records = []
        for path in (llm.journal.directory / "calls").glob("*.json"):
            record = json.loads(path.read_text(encoding="utf-8"))
            scopes = getattr(llm, "record_scopes", (llm.scope,))
            if any(record["identity"].startswith(scope + "/") for scope in scopes):
                records.append(record)
        if not records or any(record["status"] != "completed" for record in records):
            raise
        reasons = [
            record["response"]["choices"][0]["finish_reason"] for record in records
        ]
        if "length" not in reasons or any(
            reason not in ("stop", "length") for reason in reasons
        ):
            raise
        key = hashlib.sha256(llm.scope.encode()).hexdigest()
        write_json(
            llm.journal.directory / "length_failures" / f"{key}.json",
            {
                "scope": llm.scope,
                "quality": 0,
                "reason": "length",
                "calls": [r["identity"] for r in records],
            },
        )
        return ""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--confirmed-user-stop", action="store_true")
    args = parser.parse_args()
    source = args.source.resolve()
    if (source / "active.lock").exists() and not args.confirmed_user_stop:
        parser.error("source still has an active lock")
    result_path = source / "result.json"
    status = (
        json.loads(result_path.read_text(encoding="utf-8"))["status"]
        if result_path.exists()
        else None
    )
    if status == "completed":
        parser.error("source is already completed")
    if args.confirmed_user_stop:
        command = json.loads(
            (source.parent / "commands" / source.name / "run.json").read_text(
                encoding="utf-8"
            )
        )
        if command.get("status") not in ("failed", "interrupted") or not command.get(
            "ended_utc"
        ):
            parser.error("source command has not recorded termination")
    elif status != "interrupted":
        parser.error("source must be an interrupted run")
    if Path(args.name).name != args.name or args.name in ("", ".", ".."):
        parser.error("name must be a single directory name")
    if (source / "recovery.json").exists():
        protocol = json.loads((source / "recovery.json").read_text(encoding="utf-8"))[
            "original_protocol"
        ]
    else:
        protocol = json.loads((source / "protocol.json").read_text(encoding="utf-8"))
    root = Path(__file__).resolve().parents[2]
    for relative, expected in protocol["source_hashes"].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            parser.error("original experiment source changed")
    tasks = Path(protocol["tasks"])
    if hashlib.sha256(tasks.read_bytes()).hexdigest() != protocol["data_sha256"]:
        parser.error("data changed")
    data = json.loads(tasks.read_text(encoding="utf-8"))
    run.validate_tasks(data)
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(
        protocol["env_file"]
    ).get("OPENROUTER_API_KEY")
    if not key:
        parser.error("missing API key")
    directory = source.parent / args.name
    directory.mkdir(exist_ok=False)
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "original_protocol": protocol,
        "recovery_source_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
        "amendment": "length during workflow execution is quality 0; other errors still interrupt",
        "confirmed_user_stop": args.confirmed_user_stop,
        "retry_policy": "retry missing responses once; retain prior attempt costs as unknown",
        "inherited_calls": {},
    }
    manifest["inherited_calls"] = inherit_calls(
        source, directory, args.confirmed_user_stop
    )
    write_json(directory / "recovery.json", manifest)
    lock = directory / "active.lock"
    lock.write_text(str(os.getpid()), encoding="utf-8")

    async def resume():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = RecoveryJournal(directory, client)
            # The original runner remains unchanged on disk and in other processes.
            original = run.execute_workflow
            run.execute_workflow = execute_with_length_failure  # ty: ignore[invalid-assignment]
            try:
                result = await run.experiment(
                    SimpleNamespace(**protocol), directory, data, journal
                )
                result["recovered_from"] = str(source)
                result["length_failures"] = len(
                    list((directory / "length_failures").glob("*.json"))
                )
                write_json(directory / "result.json", result)
                print(json.dumps(result), flush=True)
            except BaseException as exc:
                write_json(
                    directory / "result.json",
                    {
                        "status": "interrupted",
                        "error_type": type(exc).__name__,
                        "costs": journal.costs(),
                    },
                )
                raise
            finally:
                run.execute_workflow = original
                write_json(directory / "costs.json", journal.costs())

    try:
        asyncio.run(resume())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
