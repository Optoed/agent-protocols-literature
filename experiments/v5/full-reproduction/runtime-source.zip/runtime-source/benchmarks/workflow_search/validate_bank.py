"""Evaluate frozen bank winners on fresh held-out tasks, sharing identical workflows."""

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path

import httpx
from dotenv import dotenv_values
from fedotmas_meta.workflow import WorkflowSpec

from benchmarks.workflow_search.answers import grade
from benchmarks.workflow_search.journal import (
    Journal,
    JournalLLM,
    archive_directory,
    write_json,
)
from benchmarks.workflow_search.recover import execute_with_length_failure


async def validate(plan: dict, directory: Path, journal: Journal) -> dict:
    async def evaluate(key, raw_spec):
        spec = WorkflowSpec.model_validate(raw_spec)
        if spec.fingerprint != key:
            raise ValueError("workflow fingerprint mismatch")
        rows = []
        correct = 0.0
        for task in plan["tasks"]:
            llm = JournalLLM(
                journal,
                plan["model"],
                f"validation/{key}/{task['id']}",
                "validation_execution",
            )
            answer = await execute_with_length_failure(spec, task["question"], llm)
            quality, status = grade(answer, task["answer"])
            correct += quality
            rows.append(
                {
                    "id": task["id"],
                    "quality": quality,
                    "parse_status": status,
                    "answer": answer,
                }
            )
            write_json(directory / "answers" / f"{key}.json", rows)
            print(
                json.dumps(
                    {
                        "workflow": key[:12],
                        "completed": len(rows),
                        "total": len(plan["tasks"]),
                    }
                ),
                flush=True,
            )
        return {
            "workflow": key,
            "correct": correct,
            "count": len(rows),
            "quality": correct / len(rows),
        }

    results = await asyncio.gather(
        *(evaluate(k, v) for k, v in plan["workflows"].items()), return_exceptions=True
    )
    errors = [type(r).__name__ for r in results if isinstance(r, BaseException)]
    return {
        "status": "interrupted" if errors else "completed",
        "errors": errors,
        "workflows": [r for r in results if not isinstance(r, BaseException)],
        "assignments": plan["assignments"],
        "costs": journal.costs(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    if not plan["tasks"] or len({t["id"] for t in plan["tasks"]}) != len(plan["tasks"]):
        parser.error("invalid test tasks")
    directory = archive_directory(args.plan.resolve().parent, args.name)
    protocol = {
        "plan_sha256": hashlib.sha256(args.plan.read_bytes()).hexdigest(),
        "source_hashes": {},
    }
    repo = Path(__file__).resolve().parents[2]
    for relative in [
        "benchmarks/workflow_search/validate_bank.py",
        "benchmarks/workflow_search/recover.py",
        "benchmarks/workflow_search/journal.py",
        "benchmarks/workflow_search/answers.py",
        "packages/fedotmas-meta/src/fedotmas_meta/workflow.py",
    ]:
        protocol["source_hashes"][relative] = hashlib.sha256(
            (repo / relative).read_bytes()
        ).hexdigest()
    path = directory / "protocol.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != protocol:
        parser.error("validation protocol changed")
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing API key")
    lock = directory / "active.lock"
    with lock.open("x", encoding="utf-8") as f:
        f.write(str(os.getpid()))

    async def run():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = Journal(directory, client)
            try:
                result = await validate(plan, directory, journal)
                write_json(directory / "result.json", result)
                print(json.dumps(result), flush=True)
                if result["errors"]:
                    raise RuntimeError(
                        "one or more validations interrupted; inspect journals"
                    )
            finally:
                write_json(directory / "costs.json", journal.costs())

    try:
        write_json(path, protocol)
        asyncio.run(run())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
