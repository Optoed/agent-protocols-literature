"""Freeze the paired pilot from cached source pages, excluding all previously used tasks."""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.prepare import choose
from benchmarks.workflow_search.run import validate_tasks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    args = parser.parse_args()
    root = args.runs
    output = root / "main-v3-paired-plan.json"
    if output.exists():
        parser.error("plan already exists")
    raw = root / "math-intermediate-level5-v1"
    old = json.loads((raw / "tasks.json").read_text(encoding="utf-8"))
    previous = json.loads(
        (root / "main-v2-ties-validation-plan.json").read_text(encoding="utf-8")
    )
    used = {
        t["question"].strip() for part in ("pilot", "search", "test") for t in old[part]
    }
    used.update(t["question"].strip() for t in previous["tasks"])
    source_manifest = json.loads(
        (raw / "source-manifest.json").read_text(encoding="utf-8")
    )
    plan = {
        "registered_utc": datetime.now(timezone.utc).isoformat(),
        "kind": "paired-start-estimator-pilot-not-adaptive-graph-search",
        "model": "openai/gpt-4.1-nano",
        "replicates": 2,
        "sampling_seed": 20261007,
        "source_hashes": {},
        "exclusion_count": len(used),
        "max_tokens": 8192,
        "temperature": 0.2,
        "selection": "highest search accuracy; ties prefer fewer nodes then fingerprint",
    }
    for part, split, seed in (
        ("search", "train", 20261007),
        ("test", "test", 20261008),
    ):
        rows = []
        for path in sorted(raw.glob(f"{split}-*.json")):
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != source_manifest["pages"][path.name]["sha256"]:
                raise ValueError("source snapshot changed")
            plan["source_hashes"][path.name] = digest
            rows.extend(
                r
                for r in json.loads(path.read_text(encoding="utf-8"))["rows"]
                if r["row"]["problem"].strip() not in used
            )
        plan[part] = [
            t | {"id": f"math-intermediate_algebra-{split}-{t['row_index']}"}
            for t in choose(rows, 8, seed, minimum_level=5)
        ]
    validate_tasks(plan)
    baseline = next(k for k, s in previous["workflows"].items() if len(s["nodes"]) == 1)
    prompt = previous["workflows"][baseline]["nodes"][0]["prompt"]
    swarm = next(
        k
        for k, s in previous["workflows"].items()
        if len(s["nodes"]) == 3 and s["nodes"][0]["prompt"] == prompt
    )
    plan["workflows"] = {k: previous["workflows"][k] for k in (baseline, swarm)}
    plan["previous_plan_sha256"] = hashlib.sha256(
        (root / "main-v2-ties-validation-plan.json").read_bytes()
    ).hexdigest()
    write_json(output, plan)
    print(
        json.dumps(
            {
                "plan": str(output),
                "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
                "search": 8,
                "test": 8,
                "replicates": 2,
                "maximum_calls": 176,
            }
        )
    )


if __name__ == "__main__":
    main()
