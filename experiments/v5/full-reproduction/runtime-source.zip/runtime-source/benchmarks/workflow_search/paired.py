"""Compare independent and shared-start evaluation with a separate held-out check."""

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path

import httpx
from dotenv import dotenv_values
from fedotmas_meta.workflow import WorkflowSpec

from benchmarks.workflow_search.answers import grade
from benchmarks.workflow_search.journal import (
    Journal,
    JournalLLM,
    archive_directory,
    write_json,
)
from benchmarks.workflow_search.recover import execute_with_length_failure
from benchmarks.workflow_search.run import validate_tasks
from benchmarks.workflow_search.shared_roots import SharedRoots


async def experiment(plan: dict, directory: Path, journal: Journal) -> dict:
    workflows = {
        k: WorkflowSpec.model_validate(v) for k, v in plan["workflows"].items()
    }
    if any(k != spec.fingerprint for k, spec in workflows.items()):
        raise ValueError("workflow fingerprint mismatch")
    baseline = next(k for k, spec in workflows.items() if len(spec.nodes) == 1)

    async def replicate(rep):
        scores = {}
        wins_losses = {}
        candidate_effects = {}
        winners = {}
        for mode in (
            ("independent", "shared") if rep % 2 == 0 else ("shared", "independent")
        ):
            outcomes = {k: [] for k in workflows}
            for task in plan["search"]:
                scope = f"search/rep-{rep}/{mode}/{task['id']}"
                pool = SharedRoots(
                    journal, plan["model"], scope, task["question"], f"{mode}_search"
                )
                for key, spec in workflows.items():
                    llm = (
                        pool.workflow(key)
                        if mode == "shared"
                        else JournalLLM(
                            journal, plan["model"], f"{scope}/{key}", f"{mode}_search"
                        )
                    )
                    answer = await execute_with_length_failure(
                        spec, task["question"], llm
                    )
                    quality, status = grade(answer, task["answer"])
                    outcomes[key].append(quality)
                    write_json(
                        directory
                        / "evaluations"
                        / f"{rep}-{mode}-{task['id']}-{key}.json",
                        {"quality": quality, "parse_status": status, "answer": answer},
                    )
                print(
                    json.dumps(
                        {
                            "replicate": rep,
                            "mode": mode,
                            "search_completed": len(outcomes[baseline]),
                            "total": len(plan["search"]),
                        }
                    ),
                    flush=True,
                )
            scores[mode] = {k: sum(v) / len(v) for k, v in outcomes.items()}
            candidate_effects[mode] = {
                key: {
                    "improved": sum(
                        a > b for a, b in zip(values, outcomes[baseline], strict=True)
                    ),
                    "harmed": sum(
                        a < b for a, b in zip(values, outcomes[baseline], strict=True)
                    ),
                }
                for key, values in outcomes.items()
                if key != baseline
            }
            if len(workflows) == 2:
                wins_losses[mode] = next(iter(candidate_effects[mode].values()))
            winners[mode] = min(
                workflows, key=lambda k: (-scores[mode][k], len(workflows[k].nodes), k)
            )
        write_json(
            directory / f"selection-{rep}.json",
            {
                "scores": scores,
                "wins_losses": wins_losses,
                "candidate_effects": candidate_effects,
                "winners": winners,
            },
        )
        tests = {}
        for key in sorted(set(winners.values())):
            rows: list[dict] = []
            correct = 0.0
            for task in plan["test"]:
                llm = JournalLLM(
                    journal,
                    plan["model"],
                    f"test/rep-{rep}/{key}/{task['id']}",
                    "test_execution",
                )
                answer = await execute_with_length_failure(
                    workflows[key], task["question"], llm
                )
                quality, status = grade(answer, task["answer"])
                correct += quality
                rows.append(
                    {
                        "id": task["id"],
                        "domain": task.get("domain", "unspecified"),
                        "quality": quality,
                        "parse_status": status,
                        "answer": answer,
                    }
                )
                write_json(directory / f"test-{rep}-{key}.json", rows)
                print(
                    json.dumps(
                        {
                            "replicate": rep,
                            "test_workflow": key[:12],
                            "test_completed": len(rows),
                            "total": len(plan["test"]),
                        }
                    ),
                    flush=True,
                )
            tests[key] = {
                "correct": correct,
                "count": len(rows),
                "quality": correct / len(rows),
                "by_domain": {
                    domain: {
                        "correct": sum(
                            row["quality"] for row in rows if row["domain"] == domain
                        ),
                        "count": sum(row["domain"] == domain for row in rows),
                    }
                    for domain in sorted({row["domain"] for row in rows})
                },
            }
        result = {
            "replicate": rep,
            "scores": scores,
            "wins_losses": wins_losses,
            "candidate_effects": candidate_effects,
            "winners": winners,
            "test": {
                mode: tests[key] | {"workflow": key} for mode, key in winners.items()
            },
        }
        write_json(directory / f"replicate-{rep}.json", result)
        return result

    results = await asyncio.gather(
        *(replicate(rep) for rep in range(plan["replicates"])), return_exceptions=True
    )
    errors = [type(r).__name__ for r in results if isinstance(r, BaseException)]
    return {
        "status": "interrupted" if errors else "completed",
        "errors": errors,
        "replicates": [r for r in results if not isinstance(r, BaseException)],
        "costs": journal.costs(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    validate_tasks(plan)
    if len(plan["workflows"]) < 2 or plan["replicates"] < 1:
        parser.error("requires at least two workflows and one replicate")
    if sum(len(s["nodes"]) == 1 for s in plan["workflows"].values()) != 1:
        parser.error("requires exactly one single-node baseline")
    if plan.get("max_tokens", 8192) != 8192 or plan.get("temperature", 0.2) != 0.2:
        parser.error("plan settings do not match the journal adapter")
    directory = archive_directory(args.plan.resolve().parent, args.name)
    root = Path(__file__).resolve().parents[2]
    sources = [
        Path(__file__),
        Path(__file__).with_name("shared_roots.py"),
        Path(__file__).with_name("journal.py"),
        Path(__file__).with_name("recover.py"),
        Path(__file__).with_name("answers.py"),
        Path(__file__).with_name("run.py"),
        root / "packages/fedotmas-meta/src/fedotmas_meta/workflow.py",
    ]
    manifest = {
        "plan_sha256": hashlib.sha256(args.plan.read_bytes()).hexdigest(),
        "source_hashes": {
            str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sources
        },
    }
    path = directory / "protocol.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != manifest:
        parser.error("protocol changed")
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing API key")
    lock = directory / "active.lock"
    with lock.open("x", encoding="utf-8") as f:
        f.write(str(os.getpid()))

    async def run():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = Journal(directory, client)
            try:
                result = await experiment(plan, directory, journal)
                write_json(directory / "result.json", result)
                print(json.dumps(result), flush=True)
                if result["errors"]:
                    raise RuntimeError("experiment interrupted; inspect journal")
            finally:
                write_json(directory / "costs.json", journal.costs())

    try:
        write_json(path, manifest)
        asyncio.run(run())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
