"""Run one small structural-search experiment; resume without replaying paid calls."""

import argparse
import asyncio
import hashlib
import json
import os
import re
from pathlib import Path

import httpx
from dotenv import dotenv_values
from fedotmas_meta.workflow import (
    WorkflowNode,
    WorkflowSpec,
    execute_workflow,
    propose_workflow,
)
from fedotmas_meta.workflow_search import Evaluation, search_workflows

from benchmarks.workflow_search.answers import grade
from benchmarks.workflow_search.journal import (
    Journal,
    JournalLLM,
    archive_directory,
    write_json,
)


def validate_tasks(data: dict) -> None:
    seen = set()
    questions = set()
    for split in ("search", "test"):
        if not data.get(split):
            raise ValueError(f"missing {split} tasks")
        for task in data[split]:
            if not isinstance(task["id"], str) or not re.fullmatch(
                r"[a-zA-Z0-9_-]+", task["id"]
            ):
                raise ValueError("task ID must be a safe identifier")
            if not isinstance(task["question"], str) or not task["question"].strip():
                raise ValueError("question must be nonempty text")
            if task["id"] in seen or task["question"].strip() in questions:
                raise ValueError("duplicate tasks or search/test leakage")
            seen.add(task["id"])
            questions.add(task["question"].strip())
            grade(r"\boxed{0}", task["answer"])


async def experiment(args, directory: Path, data: dict, journal: Journal) -> dict:
    search_tasks = {task["id"]: task for task in data["search"]}
    initial = WorkflowSpec(
        nodes=(
            WorkflowNode(
                name="solve",
                inputs=("question",),
                prompt="Solve the mathematics problem carefully. End with the exact rational answer in \\boxed{...}.",
            ),
        ),
        output="solve",
    )

    async def propose(parent, feedback, index):
        llm = JournalLLM(journal, args.generator, f"proposal/{index}", "proposal")
        child = await propose_workflow(parent, feedback, llm)
        write_json(
            directory / "proposals" / f"{index}.json",
            {
                "parent": parent.fingerprint,
                "child": child.model_dump(mode="json"),
                "feedback": feedback,
            },
        )
        return child

    async def evaluate(spec, task_id):
        task = search_tasks[task_id]
        scope = f"search/{spec.fingerprint}/{task_id}"
        llm = JournalLLM(journal, args.executor, scope, "search_execution")
        answer = await execute_workflow(spec, task["question"], llm)
        quality, parse_status = grade(answer, task["answer"])
        write_json(
            directory / "evaluations" / f"{spec.fingerprint}-{task_id}.json",
            {
                "quality": quality,
                "parse_status": parse_status,
                "answer": answer,
            },
        )
        return Evaluation(quality, None)

    result = await search_workflows(
        initial,
        tuple(search_tasks),
        propose,
        evaluate,
        policy=args.policy,
        rounds=args.rounds,
        seed=args.seed,
        rungs=tuple(args.rungs),
    )
    write_json(
        directory / "search.json",
        {
            "winner": result.winner.model_dump(mode="json"),
            "search_quality": result.quality,
            "decisions": result.decisions,
            "candidates": {
                k: v.model_dump(mode="json") for k, v in result.candidates.items()
            },
        },
    )
    tests = []
    qualities: list[float] = []
    for task in data["test"]:
        llm = JournalLLM(journal, args.executor, f"test/{task['id']}", "test_execution")
        answer = await execute_workflow(result.winner, task["question"], llm)
        quality, parse_status = grade(answer, task["answer"])
        row = {
            "id": task["id"],
            "quality": quality,
            "answer": answer,
            "parse_status": parse_status,
        }
        tests.append(row)
        qualities.append(quality)
        write_json(directory / "test.json", tests)
    return {
        "test_quality": sum(qualities) / len(qualities),
        "test_count": len(tests),
        "costs": journal.costs(),
        "winner": result.winner.fingerprint,
        "status": "completed",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", required=True, type=Path)
    parser.add_argument(
        "--archive-root",
        type=Path,
        default=Path(__file__).resolve().parents[3] / "workflow-runs",
    )
    parser.add_argument("--name", required=True)
    parser.add_argument(
        "--policy", choices=("full", "halving", "tie_halving"), required=True
    )
    parser.add_argument("--generator", required=True)
    parser.add_argument("--executor", required=True)
    parser.add_argument("--env-file", type=Path)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--rungs", type=int, nargs="+", default=[4, 8, 16])
    args = parser.parse_args()
    data = json.loads(args.tasks.read_text(encoding="utf-8"))
    validate_tasks(data)
    if args.rounds < 1 or args.rungs != sorted(set(args.rungs)) or args.rungs[0] < 1:
        parser.error("invalid rounds or rungs")
    if args.rungs[-1] != len(data["search"]):
        parser.error("final rung must match search task count")
    directory = archive_directory(args.archive_root, args.name)
    manifest = {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}
    manifest["data_sha256"] = hashlib.sha256(args.tasks.read_bytes()).hexdigest()
    repo = Path(__file__).resolve().parents[2]
    sources = [
        Path(__file__),
        Path(__file__).with_name("answers.py"),
        Path(__file__).with_name("journal.py"),
        repo / "packages/fedotmas-meta/src/fedotmas_meta/workflow.py",
        repo / "packages/fedotmas-meta/src/fedotmas_meta/workflow_search.py",
    ]
    manifest["source_hashes"] = {
        str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sources
    }
    path = directory / "protocol.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != manifest:
        raise ValueError("cannot resume a run with a changed protocol")
    key = os.environ.get("OPENROUTER_API_KEY")
    if not key and args.env_file:
        key = dotenv_values(args.env_file).get("OPENROUTER_API_KEY")
    if not key:
        parser.error("OPENROUTER_API_KEY must be loaded into the environment")
    lock = directory / "active.lock"
    with lock.open("x", encoding="utf-8") as output:
        output.write(str(os.getpid()))

    async def run():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = Journal(directory, client)
            try:
                report = await experiment(args, directory, data, journal)
                write_json(directory / "result.json", report)
                print(json.dumps(report))
            except BaseException as exc:
                write_json(
                    directory / "result.json",
                    {
                        "status": "interrupted",
                        "error_type": type(exc).__name__,
                        "costs": journal.costs(),
                    },
                )
                raise
            finally:
                write_json(directory / "costs.json", journal.costs())

    try:
        write_json(path, manifest)
        asyncio.run(run())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
