"""Measure one solver on the separate pilot split before starting workflow search."""

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path

import httpx
from dotenv import dotenv_values
from fedotmas_meta.workflow import WorkflowNode, WorkflowSpec, execute_workflow

from benchmarks.workflow_search.answers import grade
from benchmarks.workflow_search.journal import (
    Journal,
    JournalLLM,
    archive_directory,
    write_json,
)


async def pilot(tasks: list[dict], model: str, journal: Journal) -> dict:
    spec = WorkflowSpec(
        nodes=(
            WorkflowNode(
                name="solve",
                inputs=("question",),
                prompt="Solve the mathematics problem carefully. End with the exact rational answer in \\boxed{...}.",
            ),
        ),
        output="solve",
    )
    results = []
    correct = 0.0
    for task in tasks:
        llm = JournalLLM(journal, model, f"pilot/{task['id']}", "pilot_execution")
        answer = await execute_workflow(spec, task["question"], llm)
        quality, status = grade(answer, task["answer"])
        correct += quality
        results.append(
            {
                "id": task["id"],
                "quality": quality,
                "parse_status": status,
                "answer": answer,
            }
        )
        write_json(journal.directory / "answers.json", results)
        print(
            json.dumps(
                {"completed": len(results), "total": len(tasks), "correct": correct}
            ),
            flush=True,
        )
    return {
        "status": "completed",
        "model": model,
        "count": len(tasks),
        "quality": correct / len(tasks),
        "costs": journal.costs(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", type=Path, required=True)
    parser.add_argument(
        "--archive-root",
        type=Path,
        default=Path(__file__).resolve().parents[3] / "workflow-runs",
    )
    parser.add_argument("--name", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.tasks.read_text(encoding="utf-8"))
    tasks = data["pilot"]
    if not tasks:
        parser.error("pilot split is empty")
    directory = archive_directory(args.archive_root, args.name)
    protocol = {
        "model": args.model,
        "data_sha256": hashlib.sha256(args.tasks.read_bytes()).hexdigest(),
        "task_ids": [t["id"] for t in tasks],
        "kind": "separate-development-pilot",
    }
    path = directory / "protocol.json"
    if path.exists() and json.loads(path.read_text(encoding="utf-8")) != protocol:
        raise ValueError("pilot protocol changed")
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing OPENROUTER_API_KEY")
    lock = directory / "active.lock"
    with lock.open("x") as output:
        output.write(str(os.getpid()))

    async def run():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = Journal(directory, client)
            try:
                report = await pilot(tasks, args.model, journal)
                write_json(directory / "result.json", report)
                print(json.dumps(report), flush=True)
            finally:
                write_json(directory / "costs.json", journal.costs())

    try:
        write_json(path, protocol)
        asyncio.run(run())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
