"""Run official AFlow components with scripted responses and no network access."""

import argparse
import asyncio
import hashlib
import importlib
import json
import os
import shutil
import socket
import sys
from pathlib import Path
from types import SimpleNamespace

_CONNECT = socket.socket.connect


def no_network(sock, address):
    if isinstance(address, tuple) and address[0] in ("127.0.0.1", "::1"):
        return _CONNECT(sock, address)
    raise RuntimeError("network is forbidden in the offline AFlow probe")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    manifest = json.loads((source / "source-manifest.json").read_text())
    for name, digest in manifest["files"].items():
        if hashlib.sha256((source / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"source changed: {name}")
    output.mkdir(parents=True, exist_ok=False)
    socket.socket.connect = no_network
    sys.path.insert(0, str(source))
    sys.path.insert(0, str(output))
    os.chdir(output)
    data_module = importlib.import_module("scripts.optimizer_utils.data_utils")
    evaluation_module = importlib.import_module(
        "scripts.optimizer_utils.evaluation_utils"
    )
    optimizer_module = importlib.import_module("scripts.optimizer")
    pricing_module = importlib.import_module("scripts.async_llm")
    data_utils = data_module.DataUtils(str(output))
    probabilities = data_utils._compute_probabilities([90, 70, 50]).tolist()
    calls = []

    class FakeEvaluator:
        def __init__(self, eval_path):
            self.path = eval_path

        async def graph_evaluate(self, *args, **kwargs):
            calls.append({"repeat": len(calls), "dataset": args[0]})
            return 0.75, 0.0, 0.0

    evaluation_module.__dict__["Evaluator"] = FakeEvaluator
    optimizer = SimpleNamespace(
        dataset="MATH",
        graph=None,
        execute_llm_config={},
        round=1,
        data_utils=data_utils,
        root_path=str(output),
    )
    results = []
    observed = {}
    for repeats in (1, 5):
        calls.clear()
        score = asyncio.run(
            evaluation_module.EvaluationUtils(str(output)).evaluate_graph(
                optimizer, str(output), repeats, results
            )
        )
        assert len(calls) == repeats and score == 0.75
        observed[str(repeats)] = len(calls)
    shutil.copytree(source / "workspace/MATH", output / "workspace/MATH")
    proposals = []

    class ScriptedProposer:
        async def call_with_format(self, prompt, formatter):
            proposals.append(prompt)
            return {
                "modification": "offline scripted workflow for the smoke test",
                "prompt": "",
                "graph": (
                    "class Workflow:\n"
                    "    def __init__(self, **kwargs): pass\n"
                    "    async def __call__(self, problem):\n"
                    "        return 'scripted offline response', 0.0\n"
                ),
            }

    optimizer_module.__dict__["create_llm_instance"] = lambda config: ScriptedProposer()
    search = optimizer_module.Optimizer(
        dataset="MATH",
        question_type="math",
        opt_llm_config={},
        exec_llm_config={},
        operators=["Custom"],
        sample=4,
        optimized_path="workspace",
        max_rounds=1,
        validation_rounds=1,
    )
    asyncio.run(search._optimize_graph())
    assert len(proposals) == 1
    assert (output / "workspace/MATH/workflows/round_2/graph.py").is_file()
    report = {
        "revision": manifest["revision"],
        "kind": "offline-component-probe",
        "optimizer_imported": optimizer_module.Optimizer.__name__,
        "official_parent_probabilities": probabilities,
        "evaluation_calls_by_repeats": observed,
        "scripted_official_search_rounds": 1,
        "scripted_proposals": len(proposals),
        "unknown_model_price": pricing_module.ModelPricing.get_price(
            "unknown-research-model", "input"
        ),
        "paid_calls": 0,
        "limitations": "Scripted proposer and evaluator; no model quality measured.",
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
