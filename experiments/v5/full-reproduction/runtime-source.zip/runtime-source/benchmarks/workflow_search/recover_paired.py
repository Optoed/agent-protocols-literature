"""Resume a frozen paired experiment with preserved calls and explicit retry accounting."""

import argparse
import asyncio
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import httpx
from dotenv import dotenv_values

from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.paired import experiment
from benchmarks.workflow_search.recover import RecoveryJournal, inherit_calls
from benchmarks.workflow_search.run import validate_tasks


class TransportRecoveryJournal(RecoveryJournal):
    def __init__(self, directory: Path, client: httpx.AsyncClient, retries: int):
        super().__init__(directory, client)
        self.retries = retries

    async def request(self, identity: str, body: dict, category: str) -> dict:
        for attempt in range(self.retries + 1):
            try:
                return await super().request(identity, body, category)
            except httpx.TransportError:
                if attempt == self.retries:
                    raise
                path = (
                    self.directory
                    / "calls"
                    / f"{hashlib.sha256(identity.encode()).hexdigest()}.json"
                )
                content = path.read_bytes()
                target = (
                    self.directory
                    / "interrupted_attempts"
                    / "calls"
                    / f"{hashlib.sha256(content).hexdigest()}.json"
                )
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                if target.read_bytes() != content:
                    raise OSError("failed to preserve interrupted attempt")
                path.unlink()
                print(
                    json.dumps(
                        {
                            "transport_retry": identity,
                            "retry_number": attempt + 1,
                            "prior_cost": "unknown",
                        }
                    ),
                    flush=True,
                )
                await asyncio.sleep(2**attempt)
        raise AssertionError("unreachable")


def validate_source(source: Path, plan_path: Path, root: Path) -> dict:
    if (source / "active.lock").exists():
        raise ValueError("source still has an active lock")
    command = json.loads(
        (source.parent / "commands" / source.name / "run.json").read_text(
            encoding="utf-8"
        )
    )
    if command.get("status") not in ("failed", "interrupted") or not command.get(
        "ended_utc"
    ):
        raise ValueError("source command has not recorded termination")
    if (
        json.loads((source / "result.json").read_text(encoding="utf-8"))["status"]
        != "interrupted"
    ):
        raise ValueError("source is not interrupted")
    protocol = json.loads((source / "protocol.json").read_text(encoding="utf-8"))
    if hashlib.sha256(plan_path.read_bytes()).hexdigest() != protocol["plan_sha256"]:
        raise ValueError("frozen plan changed")
    for relative, digest in protocol["source_hashes"].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != digest:
            raise ValueError("original experiment source changed")
    return protocol


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    parser.add_argument("--retry-interrupted", action="store_true")
    parser.add_argument("--transport-retries", type=int, choices=(0, 1, 2), default=0)
    args = parser.parse_args()
    source = args.source.resolve()
    if Path(args.name).name != args.name or args.name in ("", ".", ".."):
        parser.error("name must be one directory name")
    protocol = validate_source(source, args.plan, Path(__file__).resolve().parents[2])
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    validate_tasks(plan)
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing API key")
    directory = source.parent / args.name
    directory.mkdir(exist_ok=False)
    inherited = inherit_calls(source, directory, args.retry_interrupted)
    write_json(directory / "protocol.json", protocol)
    write_json(
        directory / "recovery.json",
        {
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "source": str(source),
            "original_protocol": protocol,
            "inherited_calls": inherited,
            "retry_interrupted": args.retry_interrupted,
            "transport_retries": args.transport_retries,
            "retry_policy": "Only transport failures may retry; every failed attempt remains in interrupted_attempts with unknown cost. Completed calls are replayed without payment.",
            "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        },
    )
    lock = directory / "active.lock"
    with lock.open("x", encoding="utf-8") as f:
        f.write(str(os.getpid()))

    async def resume():
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(300, connect=30),
        ) as client:
            journal = TransportRecoveryJournal(
                directory, client, args.transport_retries
            )
            try:
                result = await experiment(plan, directory, journal)
                result["recovered_from"] = str(source)
                write_json(directory / "result.json", result)
                print(json.dumps(result), flush=True)
                if result["errors"]:
                    raise RuntimeError(
                        "recovery interrupted; inspect preserved attempts"
                    )
            finally:
                write_json(directory / "costs.json", journal.costs())

    try:
        asyncio.run(resume())
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
