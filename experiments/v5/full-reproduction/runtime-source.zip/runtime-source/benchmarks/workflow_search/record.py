"""Record a command and its output without copying environment variables."""

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from benchmarks.workflow_search.awake import keep_awake


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--keep-awake", action="store_true")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a command is required")
    args.output.mkdir(parents=True, exist_ok=False)
    record = {
        "command": command,
        "cwd": str(Path.cwd()),
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "status": "running",
        "keep_awake_requested": args.keep_awake,
    }
    path = args.output / "run.json"

    def save() -> None:
        path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")

    save()
    code = 1
    process = None
    try:
        with (
            keep_awake(args.keep_awake),
            (args.output / "output.txt").open("w", encoding="utf-8") as output,
        ):
            process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT)
            record["pid"] = process.pid
            save()
            code = process.wait()
        record.update(status="completed" if code == 0 else "failed", exit_code=code)
    except BaseException as exc:
        if process is not None and process.poll() is None:
            process.terminate()
            process.wait()
        record.update(status="interrupted", error_type=type(exc).__name__)
        raise
    finally:
        record["ended_utc"] = datetime.now(timezone.utc).isoformat()
        save()
    print(json.dumps({"output": str(args.output), "exit_code": code}))
    sys.exit(code)


if __name__ == "__main__":
    main()
