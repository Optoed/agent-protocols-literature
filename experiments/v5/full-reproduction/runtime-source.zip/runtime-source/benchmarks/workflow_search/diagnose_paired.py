"""Audit recorded paired runs without provider calls or changes to experiment results."""

import argparse
import asyncio
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import httpx

from benchmarks.workflow_search.answers import boxed, grade, rational
from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.recover import RecoveryJournal


def diagnostic_value(answer: str):
    value = boxed(answer)
    if value is None:
        return None
    value = value.removeprefix(r"\$").strip()
    value = re.sub(
        r"(?<![\d,])\d{1,3}(?:,\d{3})+(?![\d,])", lambda m: m[0].replace(",", ""), value
    )
    value = re.sub(r"^\s*[A-Za-z]\s*=\s*", "", value)
    return rational(value)


def choose(scores: dict, workflows: dict):
    return min(scores, key=lambda fp: (-scores[fp], len(workflows[fp]["nodes"]), fp))


def audit(plan_path: Path, directory: Path) -> dict:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    result = json.loads((directory / "result.json").read_text(encoding="utf-8"))
    assert result["status"] == "completed"
    labels = plan["labels"]
    report: dict = {
        "source": str(directory.resolve()),
        "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
        "official_result_sha256": hashlib.sha256(
            (directory / "result.json").read_bytes()
        ).hexdigest(),
        "replicates": [],
        "format_adjustments": [],
        "search_regrades_checked": 0,
        "unique_test_regrades_checked": 0,
    }
    cached_tests = {}
    for replicate in result["replicates"]:
        rep = replicate["replicate"]
        summary: dict = {"replicate": rep, "modes": {}}
        for mode in ("independent", "shared"):
            counts, normalized = {}, {}
            for fp in labels:
                counts[fp] = normalized[fp] = 0
                for task in plan["search"]:
                    path = (
                        directory
                        / "evaluations"
                        / f"{rep}-{mode}-{task['id']}-{fp}.json"
                    )
                    row = json.loads(path.read_text(encoding="utf-8"))
                    q, status = grade(row["answer"], task["answer"])
                    assert (q, status) == (row["quality"], row["parse_status"])
                    report["search_regrades_checked"] += 1
                    counts[fp] += q
                    updated = float(
                        diagnostic_value(row["answer"]) == rational(task["answer"])
                    )
                    normalized[fp] += updated
                    if updated != q:
                        report["format_adjustments"].append(
                            {
                                "phase": "search",
                                "replicate": rep,
                                "mode": mode,
                                "workflow": labels[fp],
                                "id": task["id"],
                                "boxed": boxed(row["answer"]),
                                "reference": task["answer"],
                                "before": q,
                                "after": updated,
                            }
                        )
                assert counts[fp] / len(plan["search"]) == replicate["scores"][mode][fp]

            winner = choose(counts, plan["workflows"])
            assert winner == replicate["winners"][mode]
            test_path = directory / f"test-{rep}-{winner}.json"
            if test_path.name not in cached_tests:
                rows = json.loads(test_path.read_text(encoding="utf-8"))
                assert len(rows) == len(plan["test"])
                for row, task in zip(rows, plan["test"], strict=True):
                    assert row["id"] == task["id"]
                    assert grade(row["answer"], task["answer"]) == (
                        row["quality"],
                        row["parse_status"],
                    )
                    report["unique_test_regrades_checked"] += 1
                    updated = float(
                        diagnostic_value(row["answer"]) == rational(task["answer"])
                    )
                    if updated != row["quality"]:
                        report["format_adjustments"].append(
                            {
                                "phase": "test",
                                "replicate": rep,
                                "workflow": labels[winner],
                                "id": task["id"],
                                "boxed": boxed(row["answer"]),
                                "reference": task["answer"],
                                "before": row["quality"],
                                "after": updated,
                            }
                        )
                cached_tests[test_path.name] = rows
            rows = cached_tests[test_path.name]
            correct = sum(row["quality"] for row in rows)
            assert correct == replicate["test"][mode]["correct"]
            summary["modes"][mode] = {
                "search_counts": {labels[k]: v for k, v in counts.items()},
                "normalized_search_counts": {
                    labels[k]: v for k, v in normalized.items()
                },
                "winner": labels[winner],
                "normalized_winner": labels[choose(normalized, plan["workflows"])],
                "top_ties": [
                    labels[k] for k, v in counts.items() if v == max(counts.values())
                ],
                "test_correct": correct,
                "normalized_test_correct_fixed_winner": sum(
                    float(diagnostic_value(row["answer"]) == rational(task["answer"]))
                    for row, task in zip(rows, plan["test"], strict=True)
                ),
                "test_count": len(rows),
            }
        summary["test_disagreements"] = []
        left = cached_tests[f"test-{rep}-{replicate['winners']['independent']}.json"]
        right = cached_tests[f"test-{rep}-{replicate['winners']['shared']}.json"]
        for a, b, task in zip(left, right, plan["test"], strict=True):
            if a["quality"] != b["quality"]:
                summary["test_disagreements"].append(
                    {
                        "id": a["id"],
                        "question": task["question"],
                        "reference": task["answer"],
                        "independent_quality": a["quality"],
                        "shared_quality": b["quality"],
                        "independent_boxed": boxed(a["answer"]),
                        "shared_boxed": boxed(b["answer"]),
                    }
                )
        report["replicates"].append(summary)
    recovery = json.loads((directory / "recovery.json").read_text(encoding="utf-8"))
    source = Path(recovery["source"])
    matched = 0
    for name, digest in recovery["inherited_calls"].items():
        before = source / "calls" / name
        assert hashlib.sha256(before.read_bytes()).hexdigest() == digest
        row = json.loads(before.read_text(encoding="utf-8"))
        target = (
            directory / "calls" / name
            if row["status"] == "completed"
            else directory / "interrupted_attempts" / "calls" / f"{digest}.json"
        )
        assert target.read_bytes() == before.read_bytes()
        matched += 1
    report["inherited_records_identical"] = matched
    report["replicate0_identical"] = json.loads(
        (source / "replicate-0.json").read_text()
    ) == json.loads((directory / "replicate-0.json").read_text())
    client = httpx.AsyncClient(
        transport=httpx.MockTransport(lambda _: httpx.Response(599))
    )
    journal = RecoveryJournal(directory, client)
    assert journal.costs() == result["costs"]
    report["costs"] = journal.costs()
    asyncio.run(client.aclose())
    report["status_counts"] = dict(
        Counter(
            json.loads(f.read_text())["status"]
            for f in (directory / "calls").glob("*.json")
        )
    )
    single = next(fp for fp, label in labels.items() if label == "single")
    triple = next(fp for fp, label in labels.items() if label == "triple_review")
    prompt = plan["workflows"][single]["nodes"][0]["prompt"]
    tasks = {task["id"]: task for task in plan["search"]}
    roots: dict = {"independent": {}, "shared": {}}
    for path in (directory / "calls").glob("*.json"):
        record = json.loads(path.read_text(encoding="utf-8"))
        parts = record["identity"].split("/")
        if parts[:2] != ["search", "rep-1"]:
            continue
        messages = record["request"]["messages"]
        if (
            messages[0]["content"] != prompt
            or json.loads(messages[1]["content"])
            != "question:\n" + tasks[parts[3]]["question"]
        ):
            continue
        if parts[2] == "independent" and parts[4] != triple:
            continue
        ordinal = parts[-2] if parts[2] == "shared" else parts[-1]
        answer = record["response"]["choices"][0]["message"]["content"]
        roots[parts[2]].setdefault(parts[3], {})[ordinal] = {
            "quality": grade(answer, tasks[parts[3]]["answer"])[0],
            "boxed": boxed(answer),
        }
    assert all(
        len(rows) == 24 and all(len(draws) == 3 for draws in rows.values())
        for rows in roots.values()
    )
    report["replicate1_triple_roots"] = roots
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    directory = args.run.resolve()
    output = args.output.resolve()
    if output == directory or directory in output.parents or output.exists():
        parser.error("write diagnostics to a new file outside the original results")
    result = audit(args.plan, directory)
    write_json(output, result)
    print(
        json.dumps(
            {
                "output": str(output),
                "search_checked": result["search_regrades_checked"],
                "test_checked": result["unique_test_regrades_checked"],
                "inherited_identical": result["inherited_records_identical"],
            }
        )
    )


if __name__ == "__main__":
    main()
