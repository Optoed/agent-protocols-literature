"""Compare evaluation policies on identical fully observed candidate banks, without API calls."""

import argparse
import hashlib
import json
import random
from pathlib import Path

from fedotmas_meta.workflow_search import survivor_count

from benchmarks.workflow_search.journal import write_json


def compare_bank(directory: Path, tasks: list[str], seed: int) -> dict:
    search = json.loads((directory / "search.json").read_text(encoding="utf-8"))
    candidates = search["candidates"]
    initial = next(d["parent"] for d in search["decisions"] if d["event"] == "proposal")
    order = tasks.copy()
    random.Random(seed).shuffle(order)
    quality = {}
    prices = {}
    for key in candidates:
        for task in tasks:
            path = directory / "evaluations" / f"{key}-{task}.json"
            quality[key, task] = json.loads(path.read_text(encoding="utf-8"))["quality"]
    paths = list((directory / "calls").glob("*.json"))
    paths += list((directory / "interrupted_attempts" / "calls").glob("*.json"))
    for path in paths:
        record = json.loads(path.read_text(encoding="utf-8"))
        parts = record["identity"].split("/")
        if parts[0] == "search":
            pair = parts[1], parts[2]
            amount, unknown = prices.get(pair, (0.0, 0))
            prices[pair] = (
                amount + (record.get("cost") or 0),
                unknown + (record.get("cost") is None),
            )

    def score(key, size):
        return sum(quality[key, task] for task in order[:size]) / size

    results = {}
    for policy in ("full", "halving", "tie_halving"):
        pool = list(candidates)
        observed = {(initial, task) for task in order}
        archive = {initial: score(initial, len(order))}
        decisions = []
        for size in (len(order),) if policy == "full" else (4, 8, len(order)):
            pool.sort(key=lambda k: (-score(k, size), len(candidates[k]["nodes"]), k))
            observed.update((key, task) for key in pool for task in order[:size])
            if size == len(order):
                archive.update({key: score(key, size) for key in pool})
            keep = survivor_count(
                [score(k, size) for k in pool],
                final=size == len(order),
                preserve_ties=policy == "tie_halving",
            )
            decisions.append(
                {
                    "size": size,
                    "scores": {k: score(k, size) for k in pool},
                    "survivors": pool[:keep],
                }
            )
            pool = pool[:keep]
        winner = min(
            archive, key=lambda k: (-archive[k], len(candidates[k]["nodes"]), k)
        )
        results[policy] = {
            "winner": winner,
            "search_quality": archive[winner],
            "evaluated_pairs": len(observed),
            "projected_known_execution_usd": sum(prices[p][0] for p in observed),
            "projected_unknown_cost_calls": sum(prices[p][1] for p in observed),
            "decisions": decisions,
        }
    return {
        "source": str(directory.resolve()),
        "seed": seed,
        "candidates": candidates,
        "policies": results,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    tasks_path = args.runs / "math-intermediate-level5-v1/tasks.json"
    data = json.loads(tasks_path.read_text(encoding="utf-8"))
    banks = [
        compare_bank(
            args.runs / f"main-v1-full-{seed}-recovery2",
            [t["id"] for t in data["search"]],
            seed,
        )
        for seed in (20261004, 20261005)
    ]
    report = {
        "kind": "retrospective-fixed-bank-replay-not-adaptive-search",
        "data_sha256": hashlib.sha256(tasks_path.read_bytes()).hexdigest(),
        "banks": banks,
    }
    write_json(args.output, report)
    for bank in banks:
        print(
            json.dumps(
                {
                    "seed": bank["seed"],
                    "policies": {
                        k: {n: v for n, v in row.items() if n != "decisions"}
                        for k, row in bank["policies"].items()
                    },
                }
            )
        )


if __name__ == "__main__":
    main()
