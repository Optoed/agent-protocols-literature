"""Check confirmation pruning, accounting and task separation without API calls."""

import itertools
import random
from types import SimpleNamespace
from typing import ClassVar

from benchmarks.workflow_search.confirmed import select
from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.progressive import (
    cell_cost,
    development,
    policy_decision,
    validation,
)


def test_race8_matches_full_confirmation_for_random_tables():
    rng = random.Random(9182)
    specs = {f"fp-{i}": SimpleNamespace(nodes=[None] * (i % 4 + 1)) for i in range(6)}
    for _ in range(3000):
        screen = {fp: rng.randrange(16, 25) for fp in specs}
        confirm = {
            fp: [{"quality": rng.randrange(2)} for _ in range(16)] for fp in specs
        }
        baseline = policy_decision("v5", screen, confirm, specs)
        race = policy_decision("race8", screen, confirm, specs)
        assert race["winner"] == baseline["winner"]
        assert set(map(tuple, race["consumed"])) <= set(
            map(tuple, baseline["consumed"])
        )


def test_race16_matches_complete_16_task_target():
    specs = {"a": SimpleNamespace(nodes=[0]), "b": SimpleNamespace(nodes=[0, 1])}
    for bits in itertools.product((0, 1), repeat=8):
        screen = {"a": 20, "b": 21}
        confirm = {
            "a": [{"quality": v} for v in bits[:4] * 4],
            "b": [{"quality": v} for v in bits[4:] * 4],
        }
        target = select(
            {fp: screen[fp] + sum(r["quality"] for r in confirm[fp]) for fp in specs},
            specs,
        )
        assert policy_decision("race16", screen, confirm, specs)["winner"] == target


def test_race_can_stop_and_preserves_tie_rule():
    specs = {"a": SimpleNamespace(nodes=[0]), "b": SimpleNamespace(nodes=[0, 1])}
    screen = {"a": 20, "b": 20}
    confirm = {"a": [{"quality": 1}] * 8, "b": [{"quality": 0}] * 8}
    race = policy_decision("race8", screen, confirm, specs)
    assert race["winner"] == "a"
    assert len(race["consumed"]) == 8


def test_single_finalist_needs_no_reserve_calls():
    specs = {"a": SimpleNamespace(nodes=[0]), "b": SimpleNamespace(nodes=[0, 1])}
    for policy in ("v5", "race8", "top2", "weighted8", "race16", "shared8"):
        assert policy_decision(policy, {"a": 23, "b": 21}, {}, specs)["consumed"] == []


def test_call_accounting_deduplicates_roots_and_preserves_unknowns():
    result = cell_cost(
        [
            {"calls": {"root": 0.1, "review-a": 0.2}},
            {"calls": {"root": 0.1, "review-b": None}},
        ]
    )
    assert result["calls"] == 3
    assert result["unknown_calls"] == 1
    assert abs(result["known_usd"] - 0.3) < 1e-12


async def test_stage_order_and_frozen_challenger(tmp_path):
    specs = {f"fp-{i}": SimpleNamespace(nodes=[0] * (i + 1)) for i in range(6)}

    class FakeEvaluation:
        plan: ClassVar[dict] = {
            "development": {
                "screen": list(range(24)),
                "reserve": list(range(16)),
                "holdout": list(range(16)),
            },
            "validation": {
                "screen": list(range(24)),
                "reserve": list(range(16)),
                "test": list(range(64)),
            },
            "development_replicates": 2,
            "validation_replicates": 3,
            "development_gate": "test rule",
        }

        def __init__(self):
            self.directory = tmp_path
            self.specs = specs
            self.journal = SimpleNamespace(costs=dict)

        async def phase(self, stage, rep, phase, tasks, keys, shared=False):
            if phase in ("holdout", "test"):
                assert (tmp_path / stage / f"selection-{rep}.json").exists()
            if stage == "validation":
                assert (tmp_path / "selected-policy.json").exists()
            return {
                fp: [
                    {
                        "id": str(i),
                        "domain": "algebra",
                        "quality": 1,
                        "calls": {
                            f"{stage}/{rep}/{phase}/{i}/{fp}": len(specs[fp].nodes)
                            * 0.001
                        },
                    }
                    for i, _ in enumerate(tasks)
                ]
                for fp in keys
            }

    evaluation = FakeEvaluation()
    result = await development(evaluation)
    assert result["selected_policy"] == "top2"
    write_json(
        tmp_path / "frozen-policy-test.json", {"selected": result["selected_policy"]}
    )
    confirmed = await validation(evaluation, result["selected_policy"])
    assert confirmed["unique_test_tasks"] == 64
    assert len(confirmed["replicates"]) == 3
    assert confirmed["positive_descriptive_result"]
