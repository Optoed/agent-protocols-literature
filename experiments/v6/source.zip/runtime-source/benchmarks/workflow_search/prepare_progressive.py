"""Register disjoint development and validation tasks before testing new policies."""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.prepare import choose
from benchmarks.workflow_search.progressive import POLICIES


def questions(value):
    if isinstance(value, dict):
        if "question" in value:
            yield value["question"].strip()
        for item in value.values():
            yield from questions(item)
    elif isinstance(value, list):
        for item in value:
            yield from questions(item)


def build_plan(runs):
    old_path = runs / "main-v5-confirmed-plan.json"
    old = json.loads(old_path.read_text(encoding="utf-8"))
    exclusions = dict(old["exclusion_source_hashes"])
    exclusions[old_path.name] = hashlib.sha256(old_path.read_bytes()).hexdigest()
    used = set()
    for name, digest in exclusions.items():
        path = runs / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
        used.update(questions(json.loads(path.read_text(encoding="utf-8"))))
    assert len(used) == 296, len(used)
    initial_excluded = len(used)
    plan: dict = {
        "version": 6,
        "registered_utc": datetime.now(timezone.utc).isoformat(),
        "model": old["model"],
        "temperature": 0.2,
        "max_tokens": 8192,
        "sampling_seed": 20261109,
        "workflows": old["workflows"],
        "labels": old["labels"],
        "policies": list(POLICIES),
        "development_replicates": 2,
        "validation_replicates": 3,
        "concurrency": 24,
        "wall_seconds": 10800,
        "excluded_previous_questions": initial_excluded,
        "exclusion_source_hashes": exclusions,
        "dataset_hashes": {},
        "development": {"screen": [], "reserve": [], "holdout": []},
        "validation": {"screen": [], "reserve": [], "test": []},
        "source_hashes": {},
        "development_gate": "At least V5 development correct count, at least 20% known search savings vs full, and either a higher correct count or at least 5% lower search cost vs V5. No unknown search attempts. Maximize correct count, minimize cost, then registered policy order. shared8 is diagnostic only. If none passes, stop without final test.",
        "validation_criterion": "At least 20% known search savings vs full, accuracy no lower than full and V5, and either accuracy higher than V5 or at least 5% lower known search cost. Descriptive only. Unknown attempts reported separately.",
        "costs": "Policy costs are the union of the exact API calls consumed by that policy, with shared roots charged once. All precomputed policy tables are actual research expenditure, not the saving of the entire research run. Failed attempts remain in actual costs and block candidate selection if their search cost is unknown.",
        "policies_description": {
            "v5": "Shared24, all candidates within one correct answer, independent8, combined score, fewer nodes then fingerprint.",
            "race8": "Same target as V5. After each reserve task discard only candidates whose optimistic final score cannot beat a leader's current lower bound, including the fixed tie rule. Stop at one remaining candidate. Same winner as V5 for any fixed response table.",
            "top2": "Confirm only the two highest-ranked near-tied primary candidates on independent8. Same combined score and tie rule.",
            "weighted8": "All near-tied candidates, independent8, each reserve correct answer counts twice. Changes primary/reserve weighting.",
            "race16": "All near-tied candidates, independent16 with exact optimistic-bound pruning. Uses more selection data than full32 and V5; cannot isolate pruning from extra data.",
            "shared8": "Diagnostic: same V5 finalists and reserve8, but roots shared among finalists. Not eligible as the final challenger in this batch.",
        },
        "comparison_coupling": "Strategies reuse matching screening, confirmation and test cells as common random numbers. Full independent answers are separate from shared and confirmation. Baseline and challenger confirmation answers are shared where the requests match. No fresh answer is counted twice in the actual bill.",
        "scope": "Same fixed bank and one model, MATH Level 5 rational-answer algebra domains. Development heldout is from source train and used to choose a policy. Final test is source test and cannot be read until the policy is frozen.",
        "expected_max_calls_before_retries": 7768,
        "cost_estimate_usd": [3, 7],
        "monetary_cutoff": None,
    }
    for domain_index, (domain, folder) in enumerate(
        (
            ("algebra", "math-algebra-data-v1"),
            ("intermediate_algebra", "math-intermediate-level5-v1"),
        )
    ):
        raw = runs / folder
        manifest = json.loads(
            (raw / "source-manifest.json").read_text(encoding="utf-8")
        )
        pages = {}
        for split in ("train", "test"):
            rows = []
            for path in sorted(raw.glob(f"{split}-*.json")):
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                assert digest == manifest["pages"][path.name]["sha256"]
                plan["dataset_hashes"][path.relative_to(runs).as_posix()] = digest
                rows.extend(json.loads(path.read_text(encoding="utf-8"))["rows"])
            pages[split] = rows
        phases = [
            ("development", "screen", "train", 12),
            ("development", "reserve", "train", 8),
            ("development", "holdout", "train", 8),
            ("validation", "screen", "train", 12),
            ("validation", "reserve", "train", 8),
            ("validation", "test", "test", 32),
        ]
        for index, (stage, part, split, size) in enumerate(phases):
            eligible = [
                r for r in pages[split] if r["row"]["problem"].strip() not in used
            ]
            selected = choose(
                eligible,
                size,
                plan["sampling_seed"] + 100 * domain_index + index,
                minimum_level=5,
            )
            for task in selected:
                task.update(
                    id=f"math-{domain}-{split}-{task['row_index']}",
                    domain=domain,
                    source_split=split,
                )
            plan[stage][part].extend(selected)
            used.update(t["question"].strip() for t in selected)
    for stage in ("development", "validation"):
        for part, tasks in plan[stage].items():
            half = len(tasks) // 2
            plan[stage][part] = [
                t for pair in zip(tasks[:half], tasks[half:], strict=True) for t in pair
            ]
    assert len(used) - initial_excluded == 160
    root = Path(__file__).resolve().parents[2]
    for path in [
        *Path(__file__).parent.glob("*.py"),
        *root.glob("packages/*/src/**/*.py"),
    ]:
        plan["source_hashes"][path.relative_to(root).as_posix()] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("registered plan already exists")
    plan = build_plan(args.runs.resolve())
    write_json(args.output, plan)
    print(
        json.dumps(
            {
                "plan": str(args.output),
                "sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
                "unique_new_tasks": 160,
            }
        )
    )


if __name__ == "__main__":
    main()
