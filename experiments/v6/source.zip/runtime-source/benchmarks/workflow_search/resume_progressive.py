"""Preserve an interrupted V6 and resume only after checking account credits."""

import argparse
import asyncio
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import httpx
from dotenv import dotenv_values

from benchmarks.workflow_search.journal import write_json
from benchmarks.workflow_search.progressive import run


async def readiness(key):
    async with httpx.AsyncClient(
        headers={"Authorization": f"Bearer {key}"}, timeout=30
    ) as client:
        account = await client.get("https://openrouter.ai/api/v1/credits")
        account.raise_for_status()
        data = account.json()["data"]
        remaining = data["total_credits"] - data["total_usage"]
        if remaining <= 0:
            raise RuntimeError("account credits exhausted; no model requests sent")
        status = await client.get("https://openrouter.ai/api/v1/key")
        status.raise_for_status()
        key_remaining = status.json()["data"].get("limit_remaining")
        if key_remaining is not None and key_remaining <= 0:
            raise RuntimeError("key allowance exhausted; no model requests sent")
        return {"account_remaining": remaining, "key_remaining": key_remaining}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--env-file", required=True, type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    if (source / "active.lock").exists():
        parser.error("source has an active lock")
    command = json.loads(
        (source.parent / "commands" / source.name / "run.json").read_text(
            encoding="utf-8-sig"
        )
    )
    if command.get("status") not in ("failed", "interrupted") or not command.get(
        "ended_utc"
    ):
        parser.error("source process has not recorded termination")
    protocol = json.loads((source / "protocol.json").read_text(encoding="utf-8"))
    if hashlib.sha256(args.plan.read_bytes()).hexdigest() != protocol["plan_sha256"]:
        parser.error("plan changed")
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    root = Path(__file__).resolve().parents[2]
    for relative, expected in plan["source_hashes"].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            parser.error("registered experiment source changed")
    # This amendment is deliberately limited to the first failed launch, which
    # returned no completed responses and made no data-dependent selections.
    records = [
        json.loads(p.read_text(encoding="utf-8"))
        for p in (source / "calls").glob("*.json")
    ]
    if (
        any(r["status"] == "completed" for r in records)
        or (source / "selected-policy.json").exists()
    ):
        parser.error("completed responses require a separate recovery audit")
    if Path(args.name).name != args.name or args.name in ("", ".", ".."):
        parser.error("name must be one directory name")
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing API key")
    credits = asyncio.run(readiness(key))
    directory = source.parent / args.name
    directory.mkdir(exist_ok=False)
    preserved = {}
    for path in (source / "calls").glob("*.json"):
        content = path.read_bytes()
        target = directory / "startup_attempts/calls" / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        preserved[path.name] = hashlib.sha256(content).hexdigest()
    startup_costs = json.loads((source / "costs.json").read_text(encoding="utf-8"))
    write_json(directory / "protocol.json", protocol)
    write_json(
        directory / "recovery.json",
        {
            "source": str(source),
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "preserved_startup_calls": preserved,
            "credits": credits,
            "worker_pid": os.getpid(),
            "startup_costs": startup_costs,
            "amendment": "Registered before any completed V6 response. Check real account credits separately from key allowance. Preserve all 25 attempts from the credit-rejected launch as startup overhead with unknown costs, outside the measured policy run. Include this overhead in the total research bill, not as zero or completed policy observations. The unknown-cost gate still blocks candidates on any unknown search attempts in the measured run. No change to tasks, model, prompts, scoring, policy definitions or data-based selection criteria.",
            "recovery_source_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
        },
    )
    lock = directory / "active.lock"
    lock.write_text(str(os.getpid()))
    try:
        result = asyncio.run(run(plan, directory, key))
        if result["status"] != "completed":
            raise RuntimeError("recovery incomplete; inspect journals")
    finally:
        costs_path = directory / "costs.json"
        if costs_path.exists():
            costs = json.loads(costs_path.read_text(encoding="utf-8"))
            for category, value in startup_costs.items():
                costs["startup_" + category] = value
            write_json(costs_path, costs)
            result_path = directory / "result.json"
            if result_path.exists():
                saved = json.loads(result_path.read_text(encoding="utf-8"))
                saved.update(startup_overhead=startup_costs, costs=costs)
                write_json(result_path, saved)
        lock.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
