"""Reject insufficient account credits even when a key allowance remains."""

import httpx
import pytest

from benchmarks.workflow_search import resume_progressive


async def test_negative_account_balance_is_not_key_allowance(monkeypatch):
    requests = []

    def handle(request):
        requests.append(request.url.path)
        return httpx.Response(
            200, json={"data": {"total_credits": 540, "total_usage": 542.21}}
        )

    real_client = httpx.AsyncClient
    monkeypatch.setattr(
        resume_progressive.httpx,
        "AsyncClient",
        lambda **kwargs: real_client(transport=httpx.MockTransport(handle), **kwargs),
    )
    with pytest.raises(RuntimeError, match="account credits exhausted"):
        await resume_progressive.readiness("test-credential")
    assert requests == ["/api/v1/credits"]


async def test_both_account_and_key_checked_without_completion(monkeypatch):
    requests = []

    def handle(request):
        requests.append(request.url.path)
        data = (
            {"total_credits": 550, "total_usage": 542.21}
            if request.url.path.endswith("credits")
            else {"limit_remaining": 5.4}
        )
        return httpx.Response(200, json={"data": data})

    real_client = httpx.AsyncClient
    monkeypatch.setattr(
        resume_progressive.httpx,
        "AsyncClient",
        lambda **kwargs: real_client(transport=httpx.MockTransport(handle), **kwargs),
    )
    result = await resume_progressive.readiness("test-credential")
    assert result["account_remaining"] > 7
    assert result["key_remaining"] == 5.4
    assert requests == ["/api/v1/credits", "/api/v1/key"]
