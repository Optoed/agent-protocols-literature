"""Screen confirmation policies, then validate one frozen choice on untouched tasks."""

import argparse
import asyncio
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx
from dotenv import dotenv_values
from fedotmas_meta.workflow import WorkflowSpec

from benchmarks.workflow_search.answers import grade as strict_grade
from benchmarks.workflow_search.answers_v2 import grade
from benchmarks.workflow_search.confirmed import finalists, select
from benchmarks.workflow_search.journal import JournalLLM, write_json
from benchmarks.workflow_search.recover import execute_with_length_failure
from benchmarks.workflow_search.recover_confirmed import StableJournal, http_details
from benchmarks.workflow_search.shared_roots import SharedRoots

POLICIES = ("v5", "race8", "top2", "weighted8", "race16", "shared8")


def policy_decision(policy, screen, confirmation, specs):
    """Return a winner and the exact confirmation cells the policy consumes."""
    chosen = finalists(screen, 1)
    if policy == "top2":
        chosen = sorted(chosen, key=lambda fp: (-screen[fp], len(specs[fp].nodes), fp))[
            :2
        ]
    if len(chosen) == 1:
        return {"winner": chosen[0], "consumed": [], "finalists": chosen}
    horizon = 16 if policy == "race16" else 8
    weight = 2 if policy == "weighted8" else 1
    scores = {fp: screen[fp] for fp in chosen}
    active = list(chosen)
    consumed = []
    for task_index in range(horizon):
        for fp in active:
            scores[fp] += weight * confirmation[fp][task_index]["quality"]
            consumed.append([task_index, fp])
        if policy in ("race8", "race16"):
            leader = select({fp: scores[fp] for fp in active}, specs)
            remaining = weight * (horizon - task_index - 1)
            active = [
                fp
                for fp in active
                if fp == leader
                or select({fp: scores[fp] + remaining, leader: scores[leader]}, specs)
                == fp
            ]
            if len(active) == 1:
                break
    return {
        "winner": select({fp: scores[fp] for fp in active}, specs),
        "consumed": consumed,
        "finalists": chosen,
    }


def cell_cost(rows):
    calls = {}
    for row in rows:
        for identity, cost in row["calls"].items():
            if identity in calls and calls[identity] != cost:
                raise ValueError("inconsistent call cost")
            calls[identity] = cost
    return {
        "known_usd": sum(c for c in calls.values() if c is not None),
        "unknown_calls": sum(c is None for c in calls.values()),
        "calls": len(calls),
    }


class LimitedJournal(StableJournal):
    def __init__(self, directory, client, secret, concurrency):
        super().__init__(directory, client, secret)
        self.slots = asyncio.Semaphore(concurrency)
        self.records = {}

    async def request(self, identity, body, category):
        async with self.slots:
            data = await super().request(identity, body, category)
        self.records[identity] = {
            "cost": data.get("usage", {}).get("cost"),
            "category": category,
        }
        return data


class Evaluation:
    def __init__(self, plan, directory, journal):
        self.plan, self.directory, self.journal = plan, directory, journal
        self.specs = {
            fp: WorkflowSpec.model_validate(value)
            for fp, value in plan["workflows"].items()
        }
        self.slots = asyncio.Semaphore(plan["concurrency"])
        self.done = {}

    async def task(self, stage, rep, phase, task, keys, shared):
        async with self.slots:
            scope = f"{stage}/{phase}/rep-{rep}/{task['id']}"
            pool = SharedRoots(
                self.journal,
                self.plan["model"],
                scope,
                task["question"],
                f"{stage}_{phase}",
            )
            result = {}
            for fp in keys:
                llm = (
                    pool.workflow(fp)
                    if shared
                    else JournalLLM(
                        self.journal,
                        self.plan["model"],
                        f"{scope}/{fp}",
                        f"{stage}_{phase}",
                    )
                )
                answer = await execute_with_length_failure(
                    self.specs[fp], task["question"], llm
                )
                quality, parse_status = grade(answer, task["answer"])
                scopes = getattr(llm, "record_scopes", {llm.scope})
                calls = {
                    identity: record["cost"]
                    for identity, record in self.journal.records.items()
                    if any(identity.startswith(prefix + "/") for prefix in scopes)
                }
                row = {
                    "id": task["id"],
                    "domain": task["domain"],
                    "quality": quality,
                    "strict_quality": strict_grade(answer, task["answer"])[0],
                    "parse_status": parse_status,
                    "answer": answer,
                    "calls": calls,
                }
                result[fp] = row
                write_json(
                    self.directory
                    / stage
                    / "evaluations"
                    / f"{rep}-{phase}-{task['id']}-{fp}.json",
                    row,
                )
            progress_key = f"{stage}/{rep}/{phase}"
            self.done[progress_key] = self.done.get(progress_key, 0) + 1
            write_json(self.directory / "progress.json", self.done)
            print(
                json.dumps(
                    {
                        "stage": stage,
                        "replicate": rep,
                        "phase": phase,
                        "tasks_completed": self.done[progress_key],
                        "workflows": len(keys),
                    }
                ),
                flush=True,
            )
            return result

    async def phase(self, stage, rep, phase, tasks, keys, shared=False):
        results = await asyncio.gather(
            *(self.task(stage, rep, phase, t, keys, shared) for t in tasks)
        )
        return {fp: [r[fp] for r in results] for fp in keys}


def score(rows):
    return {fp: sum(row["quality"] for row in values) for fp, values in rows.items()}


def summary(rows):
    return {
        "correct": sum(row["quality"] for row in rows),
        "count": len(rows),
        "by_domain": {
            domain: {
                "correct": sum(r["quality"] for r in rows if r["domain"] == domain),
                "count": sum(r["domain"] == domain for r in rows),
            }
            for domain in sorted({r["domain"] for r in rows})
        },
    }


def method_result(decision, screen, confirmation, holdout):
    consumed = [confirmation[fp][i] for i, fp in decision["consumed"]]
    base = [r for rows in screen.values() for r in rows]
    return decision | {
        "search": cell_cost(base + consumed),
        "holdout": summary(holdout[decision["winner"]]),
    }


async def development(evaluation):
    plan, directory, specs = evaluation.plan, evaluation.directory, evaluation.specs
    tasks = plan["development"]

    async def repeat(rep):
        independent, shared = await asyncio.gather(
            evaluation.phase(
                "development",
                rep,
                "independent",
                tasks["screen"] + tasks["reserve"][:8],
                list(specs),
            ),
            evaluation.phase(
                "development", rep, "shared", tasks["screen"], list(specs), True
            ),
        )
        primary = score(shared)
        chosen = finalists(primary, 1)
        confirmation, shared_confirmation = (
            {fp: [] for fp in chosen},
            {fp: [] for fp in chosen},
        )
        if len(chosen) > 1:
            confirmation, shared_confirmation = await asyncio.gather(
                evaluation.phase(
                    "development", rep, "confirmation", tasks["reserve"], chosen
                ),
                evaluation.phase(
                    "development",
                    rep,
                    "shared_confirmation",
                    tasks["reserve"][:8],
                    chosen,
                    True,
                ),
            )
        decisions = {
            policy: policy_decision(
                policy,
                primary,
                shared_confirmation if policy == "shared8" else confirmation,
                specs,
            )
            for policy in POLICIES
        }
        decisions["independent"] = {
            "winner": select(score(independent), specs),
            "consumed": [],
        }
        decisions["raw_shared"] = {"winner": select(primary, specs), "consumed": []}
        write_json(directory / "development" / f"selection-{rep}.json", decisions)
        heldout = await evaluation.phase(
            "development", rep, "holdout", tasks["holdout"], list(specs)
        )
        methods = {}
        for method, decision in decisions.items():
            matrix = shared_confirmation if method == "shared8" else confirmation
            methods[method] = method_result(
                decision,
                independent if method == "independent" else shared,
                matrix,
                heldout,
            )
        result = {"replicate": rep, "methods": methods}
        write_json(directory / "development" / f"replicate-{rep}.json", result)
        return result

    repeats = await asyncio.gather(
        *(repeat(rep) for rep in range(plan["development_replicates"]))
    )
    aggregate = {}
    for method in (*POLICIES, "independent", "raw_shared"):
        values = [r["methods"][method] for r in repeats]
        aggregate[method] = {
            "correct": sum(v["holdout"]["correct"] for v in values),
            "count": sum(v["holdout"]["count"] for v in values),
            "known_search_usd": sum(v["search"]["known_usd"] for v in values),
            "unknown_search_calls": sum(v["search"]["unknown_calls"] for v in values),
        }
    full, baseline = aggregate["independent"], aggregate["v5"]
    actual_costs = evaluation.journal.costs()
    unknown_search_attempts = sum(
        value["unknown_cost_calls"]
        for category, value in actual_costs.items()
        if category.startswith("development_") and category != "development_holdout"
    )
    eligible = []
    for method in POLICIES[1:]:
        value = aggregate[method]
        value["known_search_saving_vs_full"] = (
            1 - value["known_search_usd"] / full["known_search_usd"]
        )
        value["passes_development_gate"] = (
            value["correct"] >= baseline["correct"]
            and value["known_search_saving_vs_full"] >= 0.2
            and (
                value["correct"] > baseline["correct"]
                or value["known_search_usd"] <= 0.95 * baseline["known_search_usd"]
            )
            and value["unknown_search_calls"] == 0
            and full["unknown_search_calls"] == 0
            and unknown_search_attempts == 0
        )
        if method != "shared8" and value["passes_development_gate"]:
            eligible.append(method)
    candidate = (
        min(
            eligible,
            key=lambda m: (
                -aggregate[m]["correct"],
                aggregate[m]["known_search_usd"],
                POLICIES.index(m),
            ),
        )
        if eligible
        else None
    )
    result = {
        "status": "completed",
        "replicates": repeats,
        "aggregate": aggregate,
        "selected_policy": candidate,
        "actual_costs": actual_costs,
        "unknown_actual_search_attempts": unknown_search_attempts,
        "interpretation": "Development screening only. Multiple policies share held-out development responses; no confirmatory claim.",
    }
    write_json(directory / "development" / "result.json", result)
    write_json(
        directory / "selected-policy.json",
        {
            "selected_policy": candidate,
            "selected_utc": datetime.now(timezone.utc).isoformat(),
            "rule": plan["development_gate"],
        },
    )
    return result


async def validation(evaluation, selected):
    plan, directory, specs = evaluation.plan, evaluation.directory, evaluation.specs
    tasks = plan["validation"]

    async def repeat(rep):
        independent, shared = await asyncio.gather(
            evaluation.phase(
                "validation",
                rep,
                "independent",
                tasks["screen"] + tasks["reserve"][:8],
                list(specs),
            ),
            evaluation.phase(
                "validation", rep, "shared", tasks["screen"], list(specs), True
            ),
        )
        primary = score(shared)
        chosen = finalists(primary, 1)
        horizon = 16 if selected == "race16" else 8
        confirmation = {fp: [] for fp in chosen}
        decisions = {}
        if len(chosen) > 1:
            # Evaluate the union needed by V5 and the challenger, once. Policy costs
            # include only cells each policy requests; the union is the actual bill.
            confirmation = await evaluation.phase(
                "validation", rep, "confirmation", tasks["reserve"][:horizon], chosen
            )
        for policy in dict.fromkeys(("v5", selected)):
            decisions[policy] = policy_decision(policy, primary, confirmation, specs)
        decisions["independent"] = {
            "winner": select(score(independent), specs),
            "consumed": [],
        }
        write_json(directory / "validation" / f"selection-{rep}.json", decisions)
        heldout = await evaluation.phase(
            "validation",
            rep,
            "test",
            tasks["test"],
            sorted({d["winner"] for d in decisions.values()}),
        )
        methods = {
            method: method_result(
                decision,
                independent if method == "independent" else shared,
                confirmation,
                heldout,
            )
            for method, decision in decisions.items()
        }
        result = {"replicate": rep, "methods": methods}
        write_json(directory / "validation" / f"replicate-{rep}.json", result)
        return result

    results = await asyncio.gather(
        *(repeat(rep) for rep in range(plan["validation_replicates"]))
    )
    aggregate = {}
    for method in dict.fromkeys(("independent", "v5", selected)):
        values = [r["methods"][method] for r in results]
        aggregate[method] = {
            "correct": sum(v["holdout"]["correct"] for v in values),
            "count": sum(v["holdout"]["count"] for v in values),
            "known_search_usd": sum(v["search"]["known_usd"] for v in values),
            "unknown_search_calls": sum(v["search"]["unknown_calls"] for v in values),
        }
    candidate, full, baseline = (
        aggregate[selected],
        aggregate["independent"],
        aggregate["v5"],
    )
    saving = 1 - candidate["known_search_usd"] / full["known_search_usd"]
    positive = (
        saving >= 0.2
        and candidate["correct"] >= full["correct"]
        and candidate["correct"] >= baseline["correct"]
        and (
            candidate["correct"] > baseline["correct"]
            or candidate["known_search_usd"] <= baseline["known_search_usd"] * 0.95
        )
    )
    result = {
        "status": "completed",
        "selected_policy": selected,
        "replicates": results,
        "aggregate": aggregate,
        "known_search_saving_vs_full": saving,
        "positive_descriptive_result": positive,
        "unique_test_tasks": len(tasks["test"]),
        "interpretation": "One frozen challenger tested once. Descriptive comparison, not statistical superiority or noninferiority.",
    }
    write_json(directory / "validation" / "result.json", result)
    return result


async def run(plan, directory, key):
    async with httpx.AsyncClient(
        headers={"Authorization": f"Bearer {key}"},
        timeout=httpx.Timeout(300, connect=30),
        limits=httpx.Limits(max_connections=plan["concurrency"] + 2),
    ) as client:
        journal = LimitedJournal(directory, client, key, plan["concurrency"])
        readiness = await client.get("https://openrouter.ai/api/v1/key")
        if not readiness.is_success:
            write_json(directory / "readiness.json", http_details(readiness, key))
            raise RuntimeError("read-only readiness failed")
        evaluation = Evaluation(plan, directory, journal)
        try:
            async with asyncio.timeout(plan["wall_seconds"]):
                dev = await development(evaluation)
                if dev["selected_policy"]:
                    result = await validation(evaluation, dev["selected_policy"])
                else:
                    result = {
                        "status": "completed",
                        "validation": "not_started_no_candidate_passed",
                        "development": dev["aggregate"],
                    }
        except TimeoutError:
            result = {
                "status": "time_limit",
                "wall_seconds": plan["wall_seconds"],
                "action": "Inspect pending requests; do not resume blindly.",
            }
        except Exception as exc:
            result = {
                "status": "interrupted",
                "error_type": type(exc).__name__,
                "action": "Inspect saved calls and HTTP diagnostics. No automatic HTTP retry.",
            }
            write_json(directory / "result.json", result)
            raise
        finally:
            pending = [
                task
                for task in asyncio.all_tasks()
                if task is not asyncio.current_task() and not task.done()
            ]
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
            write_json(directory / "costs.json", journal.costs())
        result["costs"] = journal.costs()
        write_json(directory / "result.json", result)
        print(
            json.dumps(
                {
                    "status": result["status"],
                    "selected_policy": result.get("selected_policy"),
                }
            ),
            flush=True,
        )
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    if Path(args.name).name != args.name or args.name in ("", ".", ".."):
        parser.error("name must be a single directory name")
    root = Path(__file__).resolve().parents[2]
    for relative, expected in plan["source_hashes"].items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            parser.error("registered source changed")
    directory = args.plan.resolve().parent / args.name
    directory.mkdir(exist_ok=False)
    write_json(
        directory / "protocol.json",
        {
            "plan_sha256": hashlib.sha256(args.plan.read_bytes()).hexdigest(),
            "plan": plan,
            "started_utc": datetime.now(timezone.utc).isoformat(),
            "pid": os.getpid(),
        },
    )
    key = os.environ.get("OPENROUTER_API_KEY") or dotenv_values(args.env_file).get(
        "OPENROUTER_API_KEY"
    )
    if not key:
        parser.error("missing API key")
    lock = directory / "active.lock"
    lock.write_text(str(os.getpid()))
    try:
        result = asyncio.run(run(plan, directory, key))
        if result["status"] != "completed":
            sys.exit(2)
    finally:
        lock.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
